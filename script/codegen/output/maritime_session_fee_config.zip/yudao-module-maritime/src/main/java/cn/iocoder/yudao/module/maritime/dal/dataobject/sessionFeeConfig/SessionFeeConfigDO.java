package cn.iocoder.yudao.module.maritime.dal.dataobject.sessionFeeConfig;

import lombok.*;
import java.util.*;
import java.math.BigDecimal;
import java.math.BigDecimal;
import java.math.BigDecimal;
import java.math.BigDecimal;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.*;
import cn.iocoder.yudao.framework.mybatis.core.dataobject.BaseDO;

/**
 * 班期费用配置 DO
 *
 * @author Gene Ye
 */
@TableName("maritime_session_fee_config")
@KeySequence("maritime_session_fee_config_seq") // 用于 Oracle、PostgreSQL、Kingbase、DB2、H2 数据库的主键自增。如果是 MySQL 等数据库，可不写。
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SessionFeeConfigDO extends BaseDO {

    /**
     * 费用配置ID
     */
    @TableId
    private Long id;
    /**
     * 班期ID（唯一）
     */
    private Long sessionId;
    /**
     * 学费总额（元）
     */
    private BigDecimal tuitionAmount;
    /**
     * 学费说明（{"理论课":"1000","实操":"800"}）
     */
    private String tuitionDescription;
    /**
     * 定金金额（元）
     */
    private BigDecimal depositAmount;
    /**
     * 是否开启拼团
     */
    private Boolean isGrouponEnabled;
    /**
     * 拼团优惠减免金额（元）
     */
    private BigDecimal grouponDiscountAmount;
    /**
     * 拼团所需人数
     */
    private Integer grouponRequiredCount;
    /**
     * 拼团有效时间（小时）
     */
    private Integer grouponExpireHours;
    /**
     * 拼团失败降级优惠金额（元，单人可享）
     */
    private BigDecimal grouponFailDiscountAmount;
    /**
     * 推荐佣金金额（元，每成功推荐一人）
     */
    private BigDecimal referralCommissionAmount;
    /**
     * 是否开启推荐佣金
     */
    private Boolean isReferralCommissionEnabled;
    /**
     * 定金是否可退
     */
    private Boolean isDepositRefundable;
    /**
     * 尾款截止：开班前N天
     */
    private Integer balanceDueDaysBeforeStart;
    /**
     * 退款政策说明文本
     */
    private String refundPolicyText;


}
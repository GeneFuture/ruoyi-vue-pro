import request from '@/config/axios'
import type { Dayjs } from 'dayjs';

/** 班期费用配置信息 */
export interface SessionFeeConfig {
          id: number; // 费用配置ID
          sessionId?: number; // 班期ID（唯一）
          tuitionAmount?: number; // 学费总额（元）
          tuitionDescription: string; // 学费说明（{"理论课":"1000","实操":"800"}）
          depositAmount?: number; // 定金金额（元）
          isGrouponEnabled?: boolean; // 是否开启拼团
          grouponDiscountAmount?: number; // 拼团优惠减免金额（元）
          grouponRequiredCount?: number; // 拼团所需人数
          grouponExpireHours?: number; // 拼团有效时间（小时）
          grouponFailDiscountAmount?: number; // 拼团失败降级优惠金额（元，单人可享）
          referralCommissionAmount?: number; // 推荐佣金金额（元，每成功推荐一人）
          isReferralCommissionEnabled?: boolean; // 是否开启推荐佣金
          isDepositRefundable?: boolean; // 定金是否可退
          balanceDueDaysBeforeStart?: number; // 尾款截止：开班前N天
          refundPolicyText: string; // 退款政策说明文本
  }

// 班期费用配置 API
export const SessionFeeConfigApi = {
  // 查询班期费用配置分页
  getSessionFeeConfigPage: async (params: any) => {
    return await request.get({ url: `/maritime/session-fee-config/page`, params })
  },

  // 查询班期费用配置详情
  getSessionFeeConfig: async (id: number) => {
    return await request.get({ url: `/maritime/session-fee-config/get?id=` + id })
  },

  // 新增班期费用配置
  createSessionFeeConfig: async (data: SessionFeeConfig) => {
    return await request.post({ url: `/maritime/session-fee-config/create`, data })
  },

  // 修改班期费用配置
  updateSessionFeeConfig: async (data: SessionFeeConfig) => {
    return await request.put({ url: `/maritime/session-fee-config/update`, data })
  },

  // 删除班期费用配置
  deleteSessionFeeConfig: async (id: number) => {
    return await request.delete({ url: `/maritime/session-fee-config/delete?id=` + id })
  },

  /** 批量删除班期费用配置 */
  deleteSessionFeeConfigList: async (ids: number[]) => {
    return await request.delete({ url: `/maritime/session-fee-config/delete-list?ids=${ids.join(',')}` })
  },

  // 导出班期费用配置 Excel
  exportSessionFeeConfig: async (params) => {
    return await request.download({ url: `/maritime/session-fee-config/export-excel`, params })
  }
}
<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="班期ID（唯一）" prop="sessionId">
        <el-input v-model="formData.sessionId" placeholder="请输入班期ID（唯一）" />
      </el-form-item>
      <el-form-item label="学费总额（元）" prop="tuitionAmount">
        <el-input v-model="formData.tuitionAmount" placeholder="请输入学费总额（元）" />
      </el-form-item>
      <el-form-item label="学费说明（{"理论课":"1000","实操":"800"}）" prop="tuitionDescription">
        <Editor v-model="formData.tuitionDescription" height="150px" />
      </el-form-item>
      <el-form-item label="定金金额（元）" prop="depositAmount">
        <el-input v-model="formData.depositAmount" placeholder="请输入定金金额（元）" />
      </el-form-item>
      <el-form-item label="是否开启拼团" prop="isGrouponEnabled">
        <el-radio-group v-model="formData.isGrouponEnabled">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="拼团优惠减免金额（元）" prop="grouponDiscountAmount">
        <el-input v-model="formData.grouponDiscountAmount" placeholder="请输入拼团优惠减免金额（元）" />
      </el-form-item>
      <el-form-item label="拼团所需人数" prop="grouponRequiredCount">
        <el-input v-model="formData.grouponRequiredCount" placeholder="请输入拼团所需人数" />
      </el-form-item>
      <el-form-item label="拼团有效时间（小时）" prop="grouponExpireHours">
        <el-input v-model="formData.grouponExpireHours" placeholder="请输入拼团有效时间（小时）" />
      </el-form-item>
      <el-form-item label="拼团失败降级优惠金额（元，单人可享）" prop="grouponFailDiscountAmount">
        <el-input v-model="formData.grouponFailDiscountAmount" placeholder="请输入拼团失败降级优惠金额（元，单人可享）" />
      </el-form-item>
      <el-form-item label="推荐佣金金额（元，每成功推荐一人）" prop="referralCommissionAmount">
        <el-input v-model="formData.referralCommissionAmount" placeholder="请输入推荐佣金金额（元，每成功推荐一人）" />
      </el-form-item>
      <el-form-item label="是否开启推荐佣金" prop="isReferralCommissionEnabled">
        <el-radio-group v-model="formData.isReferralCommissionEnabled">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="定金是否可退" prop="isDepositRefundable">
        <el-radio-group v-model="formData.isDepositRefundable">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="尾款截止：开班前N天" prop="balanceDueDaysBeforeStart">
        <el-input v-model="formData.balanceDueDaysBeforeStart" placeholder="请输入尾款截止：开班前N天" />
      </el-form-item>
      <el-form-item label="退款政策说明文本" prop="refundPolicyText">
        <el-input v-model="formData.refundPolicyText" placeholder="请输入退款政策说明文本" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { SessionFeeConfigApi, SessionFeeConfig } from '@/api/maritime/sessionFeeConfig'

/** 班期费用配置 表单 */
defineOptions({ name: 'SessionFeeConfigForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  sessionId: undefined,
  tuitionAmount: undefined,
  tuitionDescription: undefined,
  depositAmount: undefined,
  isGrouponEnabled: undefined,
  grouponDiscountAmount: undefined,
  grouponRequiredCount: undefined,
  grouponExpireHours: undefined,
  grouponFailDiscountAmount: undefined,
  referralCommissionAmount: undefined,
  isReferralCommissionEnabled: undefined,
  isDepositRefundable: undefined,
  balanceDueDaysBeforeStart: undefined,
  refundPolicyText: undefined
})
const formRules = reactive({
  sessionId: [{ required: true, message: '班期ID（唯一）不能为空', trigger: 'blur' }],
  tuitionAmount: [{ required: true, message: '学费总额（元）不能为空', trigger: 'blur' }],
  depositAmount: [{ required: true, message: '定金金额（元）不能为空', trigger: 'blur' }],
  isGrouponEnabled: [{ required: true, message: '是否开启拼团不能为空', trigger: 'blur' }],
  grouponDiscountAmount: [{ required: true, message: '拼团优惠减免金额（元）不能为空', trigger: 'blur' }],
  grouponRequiredCount: [{ required: true, message: '拼团所需人数不能为空', trigger: 'blur' }],
  grouponExpireHours: [{ required: true, message: '拼团有效时间（小时）不能为空', trigger: 'blur' }],
  grouponFailDiscountAmount: [{ required: true, message: '拼团失败降级优惠金额（元，单人可享）不能为空', trigger: 'blur' }],
  referralCommissionAmount: [{ required: true, message: '推荐佣金金额（元，每成功推荐一人）不能为空', trigger: 'blur' }],
  isReferralCommissionEnabled: [{ required: true, message: '是否开启推荐佣金不能为空', trigger: 'blur' }],
  isDepositRefundable: [{ required: true, message: '定金是否可退不能为空', trigger: 'blur' }],
  balanceDueDaysBeforeStart: [{ required: true, message: '尾款截止：开班前N天不能为空', trigger: 'blur' }]
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await SessionFeeConfigApi.getSessionFeeConfig(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as SessionFeeConfig
    if (formType.value === 'create') {
      await SessionFeeConfigApi.createSessionFeeConfig(data)
      message.success(t('common.createSuccess'))
    } else {
      await SessionFeeConfigApi.updateSessionFeeConfig(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    sessionId: undefined,
    tuitionAmount: undefined,
    tuitionDescription: undefined,
    depositAmount: undefined,
    isGrouponEnabled: undefined,
    grouponDiscountAmount: undefined,
    grouponRequiredCount: undefined,
    grouponExpireHours: undefined,
    grouponFailDiscountAmount: undefined,
    referralCommissionAmount: undefined,
    isReferralCommissionEnabled: undefined,
    isDepositRefundable: undefined,
    balanceDueDaysBeforeStart: undefined,
    refundPolicyText: undefined
  }
  formRef.value?.resetFields()
}
</script>
<template>
  <ContentWrap>
    <!-- 搜索工作栏 -->
    <el-form
      class="-mb-15px"
      :model="queryParams"
      ref="queryFormRef"
      :inline="true"
      label-width="68px"
    >
      <el-form-item label="班期ID（唯一）" prop="sessionId">
        <el-input
          v-model="queryParams.sessionId"
          placeholder="请输入班期ID（唯一）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="学费总额（元）" prop="tuitionAmount">
        <el-input
          v-model="queryParams.tuitionAmount"
          placeholder="请输入学费总额（元）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="定金金额（元）" prop="depositAmount">
        <el-input
          v-model="queryParams.depositAmount"
          placeholder="请输入定金金额（元）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="是否开启拼团" prop="isGrouponEnabled">
        <el-select
          v-model="queryParams.isGrouponEnabled"
          placeholder="请选择是否开启拼团"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="拼团优惠减免金额（元）" prop="grouponDiscountAmount">
        <el-input
          v-model="queryParams.grouponDiscountAmount"
          placeholder="请输入拼团优惠减免金额（元）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="拼团所需人数" prop="grouponRequiredCount">
        <el-input
          v-model="queryParams.grouponRequiredCount"
          placeholder="请输入拼团所需人数"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="拼团有效时间（小时）" prop="grouponExpireHours">
        <el-input
          v-model="queryParams.grouponExpireHours"
          placeholder="请输入拼团有效时间（小时）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="拼团失败降级优惠金额（元，单人可享）" prop="grouponFailDiscountAmount">
        <el-input
          v-model="queryParams.grouponFailDiscountAmount"
          placeholder="请输入拼团失败降级优惠金额（元，单人可享）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="推荐佣金金额（元，每成功推荐一人）" prop="referralCommissionAmount">
        <el-input
          v-model="queryParams.referralCommissionAmount"
          placeholder="请输入推荐佣金金额（元，每成功推荐一人）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="是否开启推荐佣金" prop="isReferralCommissionEnabled">
        <el-select
          v-model="queryParams.isReferralCommissionEnabled"
          placeholder="请选择是否开启推荐佣金"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="定金是否可退" prop="isDepositRefundable">
        <el-select
          v-model="queryParams.isDepositRefundable"
          placeholder="请选择定金是否可退"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="尾款截止：开班前N天" prop="balanceDueDaysBeforeStart">
        <el-input
          v-model="queryParams.balanceDueDaysBeforeStart"
          placeholder="请输入尾款截止：开班前N天"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="退款政策说明文本" prop="refundPolicyText">
        <el-input
          v-model="queryParams.refundPolicyText"
          placeholder="请输入退款政策说明文本"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="创建时间" prop="createTime">
        <el-date-picker
          v-model="queryParams.createTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item>
        <el-button @click="handleQuery"><Icon icon="ep:search" class="mr-5px" /> 搜索</el-button>
        <el-button @click="resetQuery"><Icon icon="ep:refresh" class="mr-5px" /> 重置</el-button>
        <el-button
          type="primary"
          plain
          @click="openForm('create')"
          v-hasPermi="['maritime:session-fee-config:create']"
        >
          <Icon icon="ep:plus" class="mr-5px" /> 新增
        </el-button>
        <el-button
          type="success"
          plain
          @click="handleExport"
          :loading="exportLoading"
          v-hasPermi="['maritime:session-fee-config:export']"
        >
          <Icon icon="ep:download" class="mr-5px" /> 导出
        </el-button>
        <el-button
            type="danger"
            plain
            :disabled="isEmpty(checkedIds)"
            @click="handleDeleteBatch"
            v-hasPermi="['maritime:session-fee-config:delete']"
        >
          <Icon icon="ep:delete" class="mr-5px" /> 批量删除
        </el-button>
      </el-form-item>
    </el-form>
  </ContentWrap>

  <!-- 列表 -->
  <ContentWrap>
    <el-table
        row-key="id"
        v-loading="loading"
        :data="list"
        :stripe="true"
        :show-overflow-tooltip="true"
        @selection-change="handleRowCheckboxChange"
    >
    <el-table-column type="selection" width="55" />
      <el-table-column label="费用配置ID" align="center" prop="id" />
      <el-table-column label="班期ID（唯一）" align="center" prop="sessionId" />
      <el-table-column label="学费总额（元）" align="center" prop="tuitionAmount" />
      <el-table-column label="学费说明（{"理论课":"1000","实操":"800"}）" align="center" prop="tuitionDescription" />
      <el-table-column label="定金金额（元）" align="center" prop="depositAmount" />
      <el-table-column label="是否开启拼团" align="center" prop="isGrouponEnabled" />
      <el-table-column label="拼团优惠减免金额（元）" align="center" prop="grouponDiscountAmount" />
      <el-table-column label="拼团所需人数" align="center" prop="grouponRequiredCount" />
      <el-table-column label="拼团有效时间（小时）" align="center" prop="grouponExpireHours" />
      <el-table-column label="拼团失败降级优惠金额（元，单人可享）" align="center" prop="grouponFailDiscountAmount" />
      <el-table-column label="推荐佣金金额（元，每成功推荐一人）" align="center" prop="referralCommissionAmount" />
      <el-table-column label="是否开启推荐佣金" align="center" prop="isReferralCommissionEnabled" />
      <el-table-column label="定金是否可退" align="center" prop="isDepositRefundable" />
      <el-table-column label="尾款截止：开班前N天" align="center" prop="balanceDueDaysBeforeStart" />
      <el-table-column label="退款政策说明文本" align="center" prop="refundPolicyText" />
      <el-table-column
        label="创建时间"
        align="center"
        prop="createTime"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column label="操作" align="center" min-width="120px">
        <template #default="scope">
          <el-button
            link
            type="primary"
            @click="openForm('update', scope.row.id)"
            v-hasPermi="['maritime:session-fee-config:update']"
          >
            编辑
          </el-button>
          <el-button
            link
            type="danger"
            @click="handleDelete(scope.row.id)"
            v-hasPermi="['maritime:session-fee-config:delete']"
          >
            删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <Pagination
      :total="total"
      v-model:page="queryParams.pageNo"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />
  </ContentWrap>

  <!-- 表单弹窗：添加/修改 -->
  <SessionFeeConfigForm ref="formRef" @success="getList" />
</template>

<script setup lang="ts">
import { isEmpty } from '@/utils/is'
import { dateFormatter } from '@/utils/formatTime'
import download from '@/utils/download'
import { SessionFeeConfigApi, SessionFeeConfig } from '@/api/maritime/sessionFeeConfig'
import SessionFeeConfigForm from './SessionFeeConfigForm.vue'

/** 班期费用配置 列表 */
defineOptions({ name: 'SessionFeeConfig' })

const message = useMessage() // 消息弹窗
const { t } = useI18n() // 国际化

const loading = ref(true) // 列表的加载中
const list = ref<SessionFeeConfig[]>([]) // 列表的数据
const total = ref(0) // 列表的总页数
const queryParams = reactive({
  pageNo: 1,
  pageSize: 10,
  sessionId: undefined,
  tuitionAmount: undefined,
  tuitionDescription: undefined,
  depositAmount: undefined,
  isGrouponEnabled: undefined,
  grouponDiscountAmount: undefined,
  grouponRequiredCount: undefined,
  grouponExpireHours: undefined,
  grouponFailDiscountAmount: undefined,
  referralCommissionAmount: undefined,
  isReferralCommissionEnabled: undefined,
  isDepositRefundable: undefined,
  balanceDueDaysBeforeStart: undefined,
  refundPolicyText: undefined,
  createTime: []
})
const queryFormRef = ref() // 搜索的表单
const exportLoading = ref(false) // 导出的加载中

/** 查询列表 */
const getList = async () => {
  loading.value = true
  try {
    const data = await SessionFeeConfigApi.getSessionFeeConfigPage(queryParams)
    list.value = data.list
    total.value = data.total
  } finally {
    loading.value = false
  }
}

/** 搜索按钮操作 */
const handleQuery = () => {
  queryParams.pageNo = 1
  getList()
}

/** 重置按钮操作 */
const resetQuery = () => {
  queryFormRef.value.resetFields()
  handleQuery()
}

/** 添加/修改操作 */
const formRef = ref()
const openForm = (type: string, id?: number) => {
  formRef.value.open(type, id)
}

/** 删除按钮操作 */
const handleDelete = async (id: number) => {
  try {
    // 删除的二次确认
    await message.delConfirm()
    // 发起删除
    await SessionFeeConfigApi.deleteSessionFeeConfig(id)
    message.success(t('common.delSuccess'))
    // 刷新列表
    await getList()
  } catch {}
}

/** 批量删除班期费用配置 */
const handleDeleteBatch = async () => {
  try {
    // 删除的二次确认
    await message.delConfirm()
    await SessionFeeConfigApi.deleteSessionFeeConfigList(checkedIds.value);
    checkedIds.value = [];
    message.success(t('common.delSuccess'))
    await getList();
  } catch {}
}

const checkedIds = ref<number[]>([])
const handleRowCheckboxChange = (records: SessionFeeConfig[]) => {
  checkedIds.value = records.map((item) => item.id!);
}

/** 导出按钮操作 */
const handleExport = async () => {
  try {
    // 导出的二次确认
    await message.exportConfirm()
    // 发起导出
    exportLoading.value = true
    const data = await SessionFeeConfigApi.exportSessionFeeConfig(queryParams)
    download.excel(data, '班期费用配置.xls')
  } catch {
  } finally {
    exportLoading.value = false
  }
}

/** 初始化 **/
onMounted(() => {
  getList()
})
</script>
<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="手机号" prop="phone">
        <el-input v-model="formData.phone" placeholder="请输入手机号" />
      </el-form-item>
      <el-form-item label="加入黑名单原因" prop="reason">
        <el-input v-model="formData.reason" placeholder="请输入加入黑名单原因" />
      </el-form-item>
      <el-form-item label="操作人（管理员）" prop="operatorId">
        <el-input v-model="formData.operatorId" placeholder="请输入操作人（管理员）" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { RiskBlacklistApi, RiskBlacklist } from '@/api/maritime/blacklist'

/** 风控黑名单 表单 */
defineOptions({ name: 'RiskBlacklistForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  phone: undefined,
  reason: undefined,
  operatorId: undefined
})
const formRules = reactive({
  phone: [{ required: true, message: '手机号不能为空', trigger: 'blur' }],
  reason: [{ required: true, message: '加入黑名单原因不能为空', trigger: 'blur' }]
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await RiskBlacklistApi.getRiskBlacklist(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as RiskBlacklist
    if (formType.value === 'create') {
      await RiskBlacklistApi.createRiskBlacklist(data)
      message.success(t('common.createSuccess'))
    } else {
      await RiskBlacklistApi.updateRiskBlacklist(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    phone: undefined,
    reason: undefined,
    operatorId: undefined
  }
  formRef.value?.resetFields()
}
</script>
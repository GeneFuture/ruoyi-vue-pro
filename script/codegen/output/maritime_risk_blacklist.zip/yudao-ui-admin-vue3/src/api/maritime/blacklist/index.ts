import request from '@/config/axios'
import type { Dayjs } from 'dayjs';

/** 风控黑名单信息 */
export interface RiskBlacklist {
          id: number; // 黑名单ID
          phone?: string; // 手机号
          reason?: string; // 加入黑名单原因
          operatorId: number; // 操作人（管理员）
  }

// 风控黑名单 API
export const RiskBlacklistApi = {
  // 查询风控黑名单分页
  getRiskBlacklistPage: async (params: any) => {
    return await request.get({ url: `/maritime/risk-blacklist/page`, params })
  },

  // 查询风控黑名单详情
  getRiskBlacklist: async (id: number) => {
    return await request.get({ url: `/maritime/risk-blacklist/get?id=` + id })
  },

  // 新增风控黑名单
  createRiskBlacklist: async (data: RiskBlacklist) => {
    return await request.post({ url: `/maritime/risk-blacklist/create`, data })
  },

  // 修改风控黑名单
  updateRiskBlacklist: async (data: RiskBlacklist) => {
    return await request.put({ url: `/maritime/risk-blacklist/update`, data })
  },

  // 删除风控黑名单
  deleteRiskBlacklist: async (id: number) => {
    return await request.delete({ url: `/maritime/risk-blacklist/delete?id=` + id })
  },

  /** 批量删除风控黑名单 */
  deleteRiskBlacklistList: async (ids: number[]) => {
    return await request.delete({ url: `/maritime/risk-blacklist/delete-list?ids=${ids.join(',')}` })
  },

  // 导出风控黑名单 Excel
  exportRiskBlacklist: async (params) => {
    return await request.download({ url: `/maritime/risk-blacklist/export-excel`, params })
  }
}
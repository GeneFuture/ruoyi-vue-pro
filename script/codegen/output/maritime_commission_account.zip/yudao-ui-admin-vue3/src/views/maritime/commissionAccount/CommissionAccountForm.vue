<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="推荐人 member_id（唯一）" prop="memberId">
        <el-input v-model="formData.memberId" placeholder="请输入推荐人 member_id（唯一）" />
      </el-form-item>
      <el-form-item label="累计佣金总额（元）" prop="totalAmount">
        <el-input v-model="formData.totalAmount" placeholder="请输入累计佣金总额（元）" />
      </el-form-item>
      <el-form-item label="已发放金额（元）" prop="paidAmount">
        <el-input v-model="formData.paidAmount" placeholder="请输入已发放金额（元）" />
      </el-form-item>
      <el-form-item label="待发放金额（元）" prop="pendingAmount">
        <el-input v-model="formData.pendingAmount" placeholder="请输入待发放金额（元）" />
      </el-form-item>
      <el-form-item label="冻结中金额（元）" prop="frozenAmount">
        <el-input v-model="formData.frozenAmount" placeholder="请输入冻结中金额（元）" />
      </el-form-item>
      <el-form-item label="被拒绝的佣金总额（元）" prop="rejectedAmount">
        <el-input v-model="formData.rejectedAmount" placeholder="请输入被拒绝的佣金总额（元）" />
      </el-form-item>
      <el-form-item label="累计成功推荐人数" prop="totalReferralCount">
        <el-input v-model="formData.totalReferralCount" placeholder="请输入累计成功推荐人数" />
      </el-form-item>
      <el-form-item label="乐观锁版本号" prop="version">
        <el-input v-model="formData.version" placeholder="请输入乐观锁版本号" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { CommissionAccountApi, CommissionAccount } from '@/api/maritime/commissionAccount'

/** 佣金账户 表单 */
defineOptions({ name: 'CommissionAccountForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  memberId: undefined,
  totalAmount: undefined,
  paidAmount: undefined,
  pendingAmount: undefined,
  frozenAmount: undefined,
  rejectedAmount: undefined,
  totalReferralCount: undefined,
  version: undefined
})
const formRules = reactive({
  memberId: [{ required: true, message: '推荐人 member_id（唯一）不能为空', trigger: 'blur' }],
  totalAmount: [{ required: true, message: '累计佣金总额（元）不能为空', trigger: 'blur' }],
  paidAmount: [{ required: true, message: '已发放金额（元）不能为空', trigger: 'blur' }],
  pendingAmount: [{ required: true, message: '待发放金额（元）不能为空', trigger: 'blur' }],
  frozenAmount: [{ required: true, message: '冻结中金额（元）不能为空', trigger: 'blur' }],
  rejectedAmount: [{ required: true, message: '被拒绝的佣金总额（元）不能为空', trigger: 'blur' }],
  totalReferralCount: [{ required: true, message: '累计成功推荐人数不能为空', trigger: 'blur' }],
  version: [{ required: true, message: '乐观锁版本号不能为空', trigger: 'blur' }]
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await CommissionAccountApi.getCommissionAccount(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as CommissionAccount
    if (formType.value === 'create') {
      await CommissionAccountApi.createCommissionAccount(data)
      message.success(t('common.createSuccess'))
    } else {
      await CommissionAccountApi.updateCommissionAccount(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    memberId: undefined,
    totalAmount: undefined,
    paidAmount: undefined,
    pendingAmount: undefined,
    frozenAmount: undefined,
    rejectedAmount: undefined,
    totalReferralCount: undefined,
    version: undefined
  }
  formRef.value?.resetFields()
}
</script>
import request from '@/config/axios'
import type { Dayjs } from 'dayjs';

/** 佣金账户信息 */
export interface CommissionAccount {
          id: number; // 账户ID
          memberId?: number; // 推荐人 member_id（唯一）
          totalAmount?: number; // 累计佣金总额（元）
          paidAmount?: number; // 已发放金额（元）
          pendingAmount?: number; // 待发放金额（元）
          frozenAmount?: number; // 冻结中金额（元）
          rejectedAmount?: number; // 被拒绝的佣金总额（元）
          totalReferralCount?: number; // 累计成功推荐人数
          version?: number; // 乐观锁版本号
  }

// 佣金账户 API
export const CommissionAccountApi = {
  // 查询佣金账户分页
  getCommissionAccountPage: async (params: any) => {
    return await request.get({ url: `/maritime/commission-account/page`, params })
  },

  // 查询佣金账户详情
  getCommissionAccount: async (id: number) => {
    return await request.get({ url: `/maritime/commission-account/get?id=` + id })
  },

  // 新增佣金账户
  createCommissionAccount: async (data: CommissionAccount) => {
    return await request.post({ url: `/maritime/commission-account/create`, data })
  },

  // 修改佣金账户
  updateCommissionAccount: async (data: CommissionAccount) => {
    return await request.put({ url: `/maritime/commission-account/update`, data })
  },

  // 删除佣金账户
  deleteCommissionAccount: async (id: number) => {
    return await request.delete({ url: `/maritime/commission-account/delete?id=` + id })
  },

  /** 批量删除佣金账户 */
  deleteCommissionAccountList: async (ids: number[]) => {
    return await request.delete({ url: `/maritime/commission-account/delete-list?ids=${ids.join(',')}` })
  },

  // 导出佣金账户 Excel
  exportCommissionAccount: async (params) => {
    return await request.download({ url: `/maritime/commission-account/export-excel`, params })
  }
}
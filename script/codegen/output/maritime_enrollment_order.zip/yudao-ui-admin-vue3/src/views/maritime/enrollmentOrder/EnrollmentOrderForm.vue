<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="报名ID" prop="enrollmentId">
        <el-input v-model="formData.enrollmentId" placeholder="请输入报名ID" />
      </el-form-item>
      <el-form-item label="订单号（系统生成，即 PayOrderCreateReqDTO.merchantOrderId）" prop="orderNo">
        <el-input v-model="formData.orderNo" placeholder="请输入订单号（系统生成，即 PayOrderCreateReqDTO.merchantOrderId）" />
      </el-form-item>
      <el-form-item label="订单类型（DEPOSIT定金/BALANCE尾款/FULL全款一次付）" prop="orderType">
        <el-select v-model="formData.orderType" placeholder="请选择订单类型（DEPOSIT定金/BALANCE尾款/FULL全款一次付）">
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="应付金额（元）" prop="amount">
        <el-input v-model="formData.amount" placeholder="请输入应付金额（元）" />
      </el-form-item>
      <el-form-item label="ruoyi pay模块订单ID" prop="payOrderId">
        <el-input v-model="formData.payOrderId" placeholder="请输入ruoyi pay模块订单ID" />
      </el-form-item>
      <el-form-item label="支付渠道（wx_lite等）" prop="payChannel">
        <el-input v-model="formData.payChannel" placeholder="请输入支付渠道（wx_lite等）" />
      </el-form-item>
      <el-form-item label="订单状态（PENDING/PAID/CLOSED/REFUNDED）" prop="orderStatus">
        <el-radio-group v-model="formData.orderStatus">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="支付时间" prop="payTime">
        <el-date-picker
          v-model="formData.payTime"
          type="date"
          value-format="x"
          placeholder="选择支付时间"
        />
      </el-form-item>
      <el-form-item label="订单过期时间" prop="expireTime">
        <el-date-picker
          v-model="formData.expireTime"
          type="date"
          value-format="x"
          placeholder="选择订单过期时间"
        />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { EnrollmentOrderApi, EnrollmentOrder } from '@/api/maritime/enrollmentOrder'

/** 报名订单 表单 */
defineOptions({ name: 'EnrollmentOrderForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  enrollmentId: undefined,
  orderNo: undefined,
  orderType: undefined,
  amount: undefined,
  payOrderId: undefined,
  payChannel: undefined,
  orderStatus: undefined,
  payTime: undefined,
  expireTime: undefined
})
const formRules = reactive({
  enrollmentId: [{ required: true, message: '报名ID不能为空', trigger: 'blur' }],
  orderNo: [{ required: true, message: '订单号（系统生成，即 PayOrderCreateReqDTO.merchantOrderId）不能为空', trigger: 'blur' }],
  orderType: [{ required: true, message: '订单类型（DEPOSIT定金/BALANCE尾款/FULL全款一次付）不能为空', trigger: 'change' }],
  amount: [{ required: true, message: '应付金额（元）不能为空', trigger: 'blur' }],
  orderStatus: [{ required: true, message: '订单状态（PENDING/PAID/CLOSED/REFUNDED）不能为空', trigger: 'blur' }]
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await EnrollmentOrderApi.getEnrollmentOrder(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as EnrollmentOrder
    if (formType.value === 'create') {
      await EnrollmentOrderApi.createEnrollmentOrder(data)
      message.success(t('common.createSuccess'))
    } else {
      await EnrollmentOrderApi.updateEnrollmentOrder(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    enrollmentId: undefined,
    orderNo: undefined,
    orderType: undefined,
    amount: undefined,
    payOrderId: undefined,
    payChannel: undefined,
    orderStatus: undefined,
    payTime: undefined,
    expireTime: undefined
  }
  formRef.value?.resetFields()
}
</script>
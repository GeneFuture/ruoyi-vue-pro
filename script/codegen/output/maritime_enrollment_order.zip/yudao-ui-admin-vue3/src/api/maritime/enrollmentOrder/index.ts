import request from '@/config/axios'
import type { Dayjs } from 'dayjs';

/** 报名订单信息 */
export interface EnrollmentOrder {
          id: number; // 订单ID
          enrollmentId?: number; // 报名ID
          orderNo?: string; // 订单号（系统生成，即 PayOrderCreateReqDTO.merchantOrderId）
          orderType?: string; // 订单类型（DEPOSIT定金/BALANCE尾款/FULL全款一次付）
          amount?: number; // 应付金额（元）
          payOrderId: number; // ruoyi pay模块订单ID
          payChannel: string; // 支付渠道（wx_lite等）
          orderStatus?: string; // 订单状态（PENDING/PAID/CLOSED/REFUNDED）
          payTime: string | Dayjs; // 支付时间
          expireTime: string | Dayjs; // 订单过期时间
  }

// 报名订单 API
export const EnrollmentOrderApi = {
  // 查询报名订单分页
  getEnrollmentOrderPage: async (params: any) => {
    return await request.get({ url: `/maritime/enrollment-order/page`, params })
  },

  // 查询报名订单详情
  getEnrollmentOrder: async (id: number) => {
    return await request.get({ url: `/maritime/enrollment-order/get?id=` + id })
  },

  // 新增报名订单
  createEnrollmentOrder: async (data: EnrollmentOrder) => {
    return await request.post({ url: `/maritime/enrollment-order/create`, data })
  },

  // 修改报名订单
  updateEnrollmentOrder: async (data: EnrollmentOrder) => {
    return await request.put({ url: `/maritime/enrollment-order/update`, data })
  },

  // 删除报名订单
  deleteEnrollmentOrder: async (id: number) => {
    return await request.delete({ url: `/maritime/enrollment-order/delete?id=` + id })
  },

  /** 批量删除报名订单 */
  deleteEnrollmentOrderList: async (ids: number[]) => {
    return await request.delete({ url: `/maritime/enrollment-order/delete-list?ids=${ids.join(',')}` })
  },

  // 导出报名订单 Excel
  exportEnrollmentOrder: async (params) => {
    return await request.download({ url: `/maritime/enrollment-order/export-excel`, params })
  }
}
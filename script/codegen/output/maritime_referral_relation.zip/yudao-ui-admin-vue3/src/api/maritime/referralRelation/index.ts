import request from '@/config/axios'
import type { Dayjs } from 'dayjs';

/** 推荐关系信息 */
export interface ReferralRelation {
          id: number; // 推荐关系ID
          referrerMemberId?: number; // 推荐人 member_id
          referredEnrollmentId?: number; // 被推荐人的报名ID
          referredMemberId?: number; // 被推荐人 member_id
          sessionId?: number; // 班期ID
          relationStatus?: string; // 关系状态（ACTIVE/INVALID）
          invalidReason: string; // 无效原因（风控拒绝等）
          firstClickAt: string | Dayjs; // 推荐链接首次点击时间
          referralLockedAt: string | Dayjs; // 推荐关系锁定时间（被推荐人支付定金时）
  }

// 推荐关系 API
export const ReferralRelationApi = {
  // 查询推荐关系分页
  getReferralRelationPage: async (params: any) => {
    return await request.get({ url: `/maritime/referral-relation/page`, params })
  },

  // 查询推荐关系详情
  getReferralRelation: async (id: number) => {
    return await request.get({ url: `/maritime/referral-relation/get?id=` + id })
  },

  // 新增推荐关系
  createReferralRelation: async (data: ReferralRelation) => {
    return await request.post({ url: `/maritime/referral-relation/create`, data })
  },

  // 修改推荐关系
  updateReferralRelation: async (data: ReferralRelation) => {
    return await request.put({ url: `/maritime/referral-relation/update`, data })
  },

  // 删除推荐关系
  deleteReferralRelation: async (id: number) => {
    return await request.delete({ url: `/maritime/referral-relation/delete?id=` + id })
  },

  /** 批量删除推荐关系 */
  deleteReferralRelationList: async (ids: number[]) => {
    return await request.delete({ url: `/maritime/referral-relation/delete-list?ids=${ids.join(',')}` })
  },

  // 导出推荐关系 Excel
  exportReferralRelation: async (params) => {
    return await request.download({ url: `/maritime/referral-relation/export-excel`, params })
  }
}
<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="推荐人 member_id" prop="referrerMemberId">
        <el-input v-model="formData.referrerMemberId" placeholder="请输入推荐人 member_id" />
      </el-form-item>
      <el-form-item label="被推荐人的报名ID" prop="referredEnrollmentId">
        <el-input v-model="formData.referredEnrollmentId" placeholder="请输入被推荐人的报名ID" />
      </el-form-item>
      <el-form-item label="被推荐人 member_id" prop="referredMemberId">
        <el-input v-model="formData.referredMemberId" placeholder="请输入被推荐人 member_id" />
      </el-form-item>
      <el-form-item label="班期ID" prop="sessionId">
        <el-input v-model="formData.sessionId" placeholder="请输入班期ID" />
      </el-form-item>
      <el-form-item label="关系状态（ACTIVE/INVALID）" prop="relationStatus">
        <el-radio-group v-model="formData.relationStatus">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="无效原因（风控拒绝等）" prop="invalidReason">
        <el-input v-model="formData.invalidReason" placeholder="请输入无效原因（风控拒绝等）" />
      </el-form-item>
      <el-form-item label="推荐链接首次点击时间" prop="firstClickAt">
        <el-date-picker
          v-model="formData.firstClickAt"
          type="date"
          value-format="x"
          placeholder="选择推荐链接首次点击时间"
        />
      </el-form-item>
      <el-form-item label="推荐关系锁定时间（被推荐人支付定金时）" prop="referralLockedAt">
        <el-date-picker
          v-model="formData.referralLockedAt"
          type="date"
          value-format="x"
          placeholder="选择推荐关系锁定时间（被推荐人支付定金时）"
        />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { ReferralRelationApi, ReferralRelation } from '@/api/maritime/referralRelation'

/** 推荐关系 表单 */
defineOptions({ name: 'ReferralRelationForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  referrerMemberId: undefined,
  referredEnrollmentId: undefined,
  referredMemberId: undefined,
  sessionId: undefined,
  relationStatus: undefined,
  invalidReason: undefined,
  firstClickAt: undefined,
  referralLockedAt: undefined
})
const formRules = reactive({
  referrerMemberId: [{ required: true, message: '推荐人 member_id不能为空', trigger: 'blur' }],
  referredEnrollmentId: [{ required: true, message: '被推荐人的报名ID不能为空', trigger: 'blur' }],
  referredMemberId: [{ required: true, message: '被推荐人 member_id不能为空', trigger: 'blur' }],
  sessionId: [{ required: true, message: '班期ID不能为空', trigger: 'blur' }],
  relationStatus: [{ required: true, message: '关系状态（ACTIVE/INVALID）不能为空', trigger: 'blur' }]
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await ReferralRelationApi.getReferralRelation(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as ReferralRelation
    if (formType.value === 'create') {
      await ReferralRelationApi.createReferralRelation(data)
      message.success(t('common.createSuccess'))
    } else {
      await ReferralRelationApi.updateReferralRelation(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    referrerMemberId: undefined,
    referredEnrollmentId: undefined,
    referredMemberId: undefined,
    sessionId: undefined,
    relationStatus: undefined,
    invalidReason: undefined,
    firstClickAt: undefined,
    referralLockedAt: undefined
  }
  formRef.value?.resetFields()
}
</script>
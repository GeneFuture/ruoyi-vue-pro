// TODO 待办：请将下面的错误码复制到 yudao-module-maritime 模块的 ErrorCodeConstants 类中。注意，请给“TODO 补充编号”设置一个错误码编号！！！
// ========== 推荐关系 TODO 补充编号 ==========
ErrorCode REFERRAL_RELATION_NOT_EXISTS = new ErrorCode(TODO 补充编号, "推荐关系不存在");
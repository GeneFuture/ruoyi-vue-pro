import request from '@/config/axios'
import type { Dayjs } from 'dayjs';

/** 退费申请信息 */
export interface RefundApply {
          id: number; // 退费申请ID
          enrollmentId?: number; // 报名ID
          orderId: number; // 关联报名订单ID（maritime_enrollment_order.id，退哪笔订单）
          memberId?: number; // 申请人
          applyReason?: string; // 退费原因
          refundAmount: number; // 退费金额（元，审核后填写）
          applyStatus?: string; // 申请状态（PENDING/APPROVED/REJECTED/REFUNDED）
          adminRemark: string; // 管理员备注
          approveTime: string | Dayjs; // 审核时间
          approverId: number; // 审核人（系统用户ID）
          payRefundId: number; // ruoyi pay_refund.id（退款发起后填写）
          refundTime: string | Dayjs; // 实际退款到账时间
  }

// 退费申请 API
export const RefundApplyApi = {
  // 查询退费申请分页
  getRefundApplyPage: async (params: any) => {
    return await request.get({ url: `/maritime/refund-apply/page`, params })
  },

  // 查询退费申请详情
  getRefundApply: async (id: number) => {
    return await request.get({ url: `/maritime/refund-apply/get?id=` + id })
  },

  // 新增退费申请
  createRefundApply: async (data: RefundApply) => {
    return await request.post({ url: `/maritime/refund-apply/create`, data })
  },

  // 修改退费申请
  updateRefundApply: async (data: RefundApply) => {
    return await request.put({ url: `/maritime/refund-apply/update`, data })
  },

  // 删除退费申请
  deleteRefundApply: async (id: number) => {
    return await request.delete({ url: `/maritime/refund-apply/delete?id=` + id })
  },

  /** 批量删除退费申请 */
  deleteRefundApplyList: async (ids: number[]) => {
    return await request.delete({ url: `/maritime/refund-apply/delete-list?ids=${ids.join(',')}` })
  },

  // 导出退费申请 Excel
  exportRefundApply: async (params) => {
    return await request.download({ url: `/maritime/refund-apply/export-excel`, params })
  }
}
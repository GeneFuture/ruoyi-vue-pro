<template>
  <ContentWrap>
    <!-- 搜索工作栏 -->
    <el-form
      class="-mb-15px"
      :model="queryParams"
      ref="queryFormRef"
      :inline="true"
      label-width="68px"
    >
      <el-form-item label="报名ID" prop="enrollmentId">
        <el-input
          v-model="queryParams.enrollmentId"
          placeholder="请输入报名ID"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="关联报名订单ID（maritime_enrollment_order.id，退哪笔订单）" prop="orderId">
        <el-input
          v-model="queryParams.orderId"
          placeholder="请输入关联报名订单ID（maritime_enrollment_order.id，退哪笔订单）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="申请人" prop="memberId">
        <el-input
          v-model="queryParams.memberId"
          placeholder="请输入申请人"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="退费原因" prop="applyReason">
        <el-input
          v-model="queryParams.applyReason"
          placeholder="请输入退费原因"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="退费金额（元，审核后填写）" prop="refundAmount">
        <el-input
          v-model="queryParams.refundAmount"
          placeholder="请输入退费金额（元，审核后填写）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="申请状态（PENDING/APPROVED/REJECTED/REFUNDED）" prop="applyStatus">
        <el-select
          v-model="queryParams.applyStatus"
          placeholder="请选择申请状态（PENDING/APPROVED/REJECTED/REFUNDED）"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="管理员备注" prop="adminRemark">
        <el-input
          v-model="queryParams.adminRemark"
          placeholder="请输入管理员备注"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="审核时间" prop="approveTime">
        <el-date-picker
          v-model="queryParams.approveTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item label="审核人（系统用户ID）" prop="approverId">
        <el-input
          v-model="queryParams.approverId"
          placeholder="请输入审核人（系统用户ID）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="ruoyi pay_refund.id（退款发起后填写）" prop="payRefundId">
        <el-input
          v-model="queryParams.payRefundId"
          placeholder="请输入ruoyi pay_refund.id（退款发起后填写）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="实际退款到账时间" prop="refundTime">
        <el-date-picker
          v-model="queryParams.refundTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item label="创建时间" prop="createTime">
        <el-date-picker
          v-model="queryParams.createTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item>
        <el-button @click="handleQuery"><Icon icon="ep:search" class="mr-5px" /> 搜索</el-button>
        <el-button @click="resetQuery"><Icon icon="ep:refresh" class="mr-5px" /> 重置</el-button>
        <el-button
          type="primary"
          plain
          @click="openForm('create')"
          v-hasPermi="['maritime:refund-apply:create']"
        >
          <Icon icon="ep:plus" class="mr-5px" /> 新增
        </el-button>
        <el-button
          type="success"
          plain
          @click="handleExport"
          :loading="exportLoading"
          v-hasPermi="['maritime:refund-apply:export']"
        >
          <Icon icon="ep:download" class="mr-5px" /> 导出
        </el-button>
        <el-button
            type="danger"
            plain
            :disabled="isEmpty(checkedIds)"
            @click="handleDeleteBatch"
            v-hasPermi="['maritime:refund-apply:delete']"
        >
          <Icon icon="ep:delete" class="mr-5px" /> 批量删除
        </el-button>
      </el-form-item>
    </el-form>
  </ContentWrap>

  <!-- 列表 -->
  <ContentWrap>
    <el-table
        row-key="id"
        v-loading="loading"
        :data="list"
        :stripe="true"
        :show-overflow-tooltip="true"
        @selection-change="handleRowCheckboxChange"
    >
    <el-table-column type="selection" width="55" />
      <el-table-column label="退费申请ID" align="center" prop="id" />
      <el-table-column label="报名ID" align="center" prop="enrollmentId" />
      <el-table-column label="关联报名订单ID（maritime_enrollment_order.id，退哪笔订单）" align="center" prop="orderId" />
      <el-table-column label="申请人" align="center" prop="memberId" />
      <el-table-column label="退费原因" align="center" prop="applyReason" />
      <el-table-column label="退费金额（元，审核后填写）" align="center" prop="refundAmount" />
      <el-table-column label="申请状态（PENDING/APPROVED/REJECTED/REFUNDED）" align="center" prop="applyStatus" />
      <el-table-column label="管理员备注" align="center" prop="adminRemark" />
      <el-table-column
        label="审核时间"
        align="center"
        prop="approveTime"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column label="审核人（系统用户ID）" align="center" prop="approverId" />
      <el-table-column label="ruoyi pay_refund.id（退款发起后填写）" align="center" prop="payRefundId" />
      <el-table-column
        label="实际退款到账时间"
        align="center"
        prop="refundTime"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column
        label="创建时间"
        align="center"
        prop="createTime"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column label="操作" align="center" min-width="120px">
        <template #default="scope">
          <el-button
            link
            type="primary"
            @click="openForm('update', scope.row.id)"
            v-hasPermi="['maritime:refund-apply:update']"
          >
            编辑
          </el-button>
          <el-button
            link
            type="danger"
            @click="handleDelete(scope.row.id)"
            v-hasPermi="['maritime:refund-apply:delete']"
          >
            删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <Pagination
      :total="total"
      v-model:page="queryParams.pageNo"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />
  </ContentWrap>

  <!-- 表单弹窗：添加/修改 -->
  <RefundApplyForm ref="formRef" @success="getList" />
</template>

<script setup lang="ts">
import { isEmpty } from '@/utils/is'
import { dateFormatter } from '@/utils/formatTime'
import download from '@/utils/download'
import { RefundApplyApi, RefundApply } from '@/api/maritime/refundApply'
import RefundApplyForm from './RefundApplyForm.vue'

/** 退费申请 列表 */
defineOptions({ name: 'RefundApply' })

const message = useMessage() // 消息弹窗
const { t } = useI18n() // 国际化

const loading = ref(true) // 列表的加载中
const list = ref<RefundApply[]>([]) // 列表的数据
const total = ref(0) // 列表的总页数
const queryParams = reactive({
  pageNo: 1,
  pageSize: 10,
  enrollmentId: undefined,
  orderId: undefined,
  memberId: undefined,
  applyReason: undefined,
  refundAmount: undefined,
  applyStatus: undefined,
  adminRemark: undefined,
  approveTime: [],
  approverId: undefined,
  payRefundId: undefined,
  refundTime: [],
  createTime: []
})
const queryFormRef = ref() // 搜索的表单
const exportLoading = ref(false) // 导出的加载中

/** 查询列表 */
const getList = async () => {
  loading.value = true
  try {
    const data = await RefundApplyApi.getRefundApplyPage(queryParams)
    list.value = data.list
    total.value = data.total
  } finally {
    loading.value = false
  }
}

/** 搜索按钮操作 */
const handleQuery = () => {
  queryParams.pageNo = 1
  getList()
}

/** 重置按钮操作 */
const resetQuery = () => {
  queryFormRef.value.resetFields()
  handleQuery()
}

/** 添加/修改操作 */
const formRef = ref()
const openForm = (type: string, id?: number) => {
  formRef.value.open(type, id)
}

/** 删除按钮操作 */
const handleDelete = async (id: number) => {
  try {
    // 删除的二次确认
    await message.delConfirm()
    // 发起删除
    await RefundApplyApi.deleteRefundApply(id)
    message.success(t('common.delSuccess'))
    // 刷新列表
    await getList()
  } catch {}
}

/** 批量删除退费申请 */
const handleDeleteBatch = async () => {
  try {
    // 删除的二次确认
    await message.delConfirm()
    await RefundApplyApi.deleteRefundApplyList(checkedIds.value);
    checkedIds.value = [];
    message.success(t('common.delSuccess'))
    await getList();
  } catch {}
}

const checkedIds = ref<number[]>([])
const handleRowCheckboxChange = (records: RefundApply[]) => {
  checkedIds.value = records.map((item) => item.id!);
}

/** 导出按钮操作 */
const handleExport = async () => {
  try {
    // 导出的二次确认
    await message.exportConfirm()
    // 发起导出
    exportLoading.value = true
    const data = await RefundApplyApi.exportRefundApply(queryParams)
    download.excel(data, '退费申请.xls')
  } catch {
  } finally {
    exportLoading.value = false
  }
}

/** 初始化 **/
onMounted(() => {
  getList()
})
</script>
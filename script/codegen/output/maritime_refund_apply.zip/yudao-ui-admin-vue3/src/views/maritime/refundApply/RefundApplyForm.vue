<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="报名ID" prop="enrollmentId">
        <el-input v-model="formData.enrollmentId" placeholder="请输入报名ID" />
      </el-form-item>
      <el-form-item label="关联报名订单ID（maritime_enrollment_order.id，退哪笔订单）" prop="orderId">
        <el-input v-model="formData.orderId" placeholder="请输入关联报名订单ID（maritime_enrollment_order.id，退哪笔订单）" />
      </el-form-item>
      <el-form-item label="申请人" prop="memberId">
        <el-input v-model="formData.memberId" placeholder="请输入申请人" />
      </el-form-item>
      <el-form-item label="退费原因" prop="applyReason">
        <el-input v-model="formData.applyReason" placeholder="请输入退费原因" />
      </el-form-item>
      <el-form-item label="退费金额（元，审核后填写）" prop="refundAmount">
        <el-input v-model="formData.refundAmount" placeholder="请输入退费金额（元，审核后填写）" />
      </el-form-item>
      <el-form-item label="申请状态（PENDING/APPROVED/REJECTED/REFUNDED）" prop="applyStatus">
        <el-radio-group v-model="formData.applyStatus">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="管理员备注" prop="adminRemark">
        <el-input v-model="formData.adminRemark" placeholder="请输入管理员备注" />
      </el-form-item>
      <el-form-item label="审核时间" prop="approveTime">
        <el-date-picker
          v-model="formData.approveTime"
          type="date"
          value-format="x"
          placeholder="选择审核时间"
        />
      </el-form-item>
      <el-form-item label="审核人（系统用户ID）" prop="approverId">
        <el-input v-model="formData.approverId" placeholder="请输入审核人（系统用户ID）" />
      </el-form-item>
      <el-form-item label="ruoyi pay_refund.id（退款发起后填写）" prop="payRefundId">
        <el-input v-model="formData.payRefundId" placeholder="请输入ruoyi pay_refund.id（退款发起后填写）" />
      </el-form-item>
      <el-form-item label="实际退款到账时间" prop="refundTime">
        <el-date-picker
          v-model="formData.refundTime"
          type="date"
          value-format="x"
          placeholder="选择实际退款到账时间"
        />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { RefundApplyApi, RefundApply } from '@/api/maritime/refundApply'

/** 退费申请 表单 */
defineOptions({ name: 'RefundApplyForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  enrollmentId: undefined,
  orderId: undefined,
  memberId: undefined,
  applyReason: undefined,
  refundAmount: undefined,
  applyStatus: undefined,
  adminRemark: undefined,
  approveTime: undefined,
  approverId: undefined,
  payRefundId: undefined,
  refundTime: undefined
})
const formRules = reactive({
  enrollmentId: [{ required: true, message: '报名ID不能为空', trigger: 'blur' }],
  memberId: [{ required: true, message: '申请人不能为空', trigger: 'blur' }],
  applyReason: [{ required: true, message: '退费原因不能为空', trigger: 'blur' }],
  applyStatus: [{ required: true, message: '申请状态（PENDING/APPROVED/REJECTED/REFUNDED）不能为空', trigger: 'blur' }]
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await RefundApplyApi.getRefundApply(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as RefundApply
    if (formType.value === 'create') {
      await RefundApplyApi.createRefundApply(data)
      message.success(t('common.createSuccess'))
    } else {
      await RefundApplyApi.updateRefundApply(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    enrollmentId: undefined,
    orderId: undefined,
    memberId: undefined,
    applyReason: undefined,
    refundAmount: undefined,
    applyStatus: undefined,
    adminRemark: undefined,
    approveTime: undefined,
    approverId: undefined,
    payRefundId: undefined,
    refundTime: undefined
  }
  formRef.value?.resetFields()
}
</script>
import request from '@/config/axios'
import type { Dayjs } from 'dayjs';

/** 拼团记录信息 */
export interface GrouponRecord {
          id: number; // 拼团记录ID
          sessionId?: number; // 班期ID
          inviteCode?: string; // 拼团邀请码（唯一）
          initiatorEnrollmentId?: number; // 发起人报名ID
          requiredCount?: number; // 需要人数
          currentCount?: number; // 当前人数
          grouponStatus?: string; // 拼团状态（IN_PROGRESS/SUCCESS/DEGRADED）
          expireTime?: string | Dayjs; // 拼团截止时间
          successTime: string | Dayjs; // 拼团成功时间
  }

// 拼团记录 API
export const GrouponRecordApi = {
  // 查询拼团记录分页
  getGrouponRecordPage: async (params: any) => {
    return await request.get({ url: `/maritime/groupon-record/page`, params })
  },

  // 查询拼团记录详情
  getGrouponRecord: async (id: number) => {
    return await request.get({ url: `/maritime/groupon-record/get?id=` + id })
  },

  // 新增拼团记录
  createGrouponRecord: async (data: GrouponRecord) => {
    return await request.post({ url: `/maritime/groupon-record/create`, data })
  },

  // 修改拼团记录
  updateGrouponRecord: async (data: GrouponRecord) => {
    return await request.put({ url: `/maritime/groupon-record/update`, data })
  },

  // 删除拼团记录
  deleteGrouponRecord: async (id: number) => {
    return await request.delete({ url: `/maritime/groupon-record/delete?id=` + id })
  },

  /** 批量删除拼团记录 */
  deleteGrouponRecordList: async (ids: number[]) => {
    return await request.delete({ url: `/maritime/groupon-record/delete-list?ids=${ids.join(',')}` })
  },

  // 导出拼团记录 Excel
  exportGrouponRecord: async (params) => {
    return await request.download({ url: `/maritime/groupon-record/export-excel`, params })
  }
}
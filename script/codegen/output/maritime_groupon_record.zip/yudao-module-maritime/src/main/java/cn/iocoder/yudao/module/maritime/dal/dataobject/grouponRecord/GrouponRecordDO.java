package cn.iocoder.yudao.module.maritime.dal.dataobject.grouponRecord;

import lombok.*;
import java.util.*;
import java.time.LocalDateTime;
import java.time.LocalDateTime;
import java.time.LocalDateTime;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.*;
import cn.iocoder.yudao.framework.mybatis.core.dataobject.BaseDO;

/**
 * 拼团记录 DO
 *
 * @author Gene Ye
 */
@TableName("maritime_groupon_record")
@KeySequence("maritime_groupon_record_seq") // 用于 Oracle、PostgreSQL、Kingbase、DB2、H2 数据库的主键自增。如果是 MySQL 等数据库，可不写。
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GrouponRecordDO extends BaseDO {

    /**
     * 拼团记录ID
     */
    @TableId
    private Long id;
    /**
     * 班期ID
     */
    private Long sessionId;
    /**
     * 拼团邀请码（唯一）
     */
    private String inviteCode;
    /**
     * 发起人报名ID
     */
    private Long initiatorEnrollmentId;
    /**
     * 需要人数
     */
    private Integer requiredCount;
    /**
     * 当前人数
     */
    private Integer currentCount;
    /**
     * 拼团状态（IN_PROGRESS/SUCCESS/DEGRADED）
     */
    private String grouponStatus;
    /**
     * 拼团截止时间
     */
    private LocalDateTime expireTime;
    /**
     * 拼团成功时间
     */
    private LocalDateTime successTime;


}
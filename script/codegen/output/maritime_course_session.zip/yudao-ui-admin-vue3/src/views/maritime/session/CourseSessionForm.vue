<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="课程ID" prop="courseId">
        <el-input v-model="formData.courseId" placeholder="请输入课程ID" />
      </el-form-item>
      <el-form-item label="班期编号（如：2026-06-SH-001）" prop="sessionCode">
        <el-input v-model="formData.sessionCode" placeholder="请输入班期编号（如：2026-06-SH-001）" />
      </el-form-item>
      <el-form-item label="班级名称（可选，如：A班）" prop="sessionName">
        <el-input v-model="formData.sessionName" placeholder="请输入班级名称（可选，如：A班）" />
      </el-form-item>
      <el-form-item label="本期上课地点" prop="location">
        <el-input v-model="formData.location" placeholder="请输入本期上课地点" />
      </el-form-item>
      <el-form-item label="本期课程天数" prop="durationDays">
        <el-input v-model="formData.durationDays" placeholder="请输入本期课程天数" />
      </el-form-item>
      <el-form-item label="本期讲师信息" prop="instructorInfo">
        <el-input v-model="formData.instructorInfo" placeholder="请输入本期讲师信息" />
      </el-form-item>
      <el-form-item label="开班日期" prop="startDate">
        <el-date-picker
          v-model="formData.startDate"
          type="date"
          value-format="x"
          placeholder="选择开班日期"
        />
      </el-form-item>
      <el-form-item label="结束日期" prop="endDate">
        <el-date-picker
          v-model="formData.endDate"
          type="date"
          value-format="x"
          placeholder="选择结束日期"
        />
      </el-form-item>
      <el-form-item label="报名截止日期" prop="enrollmentDeadline">
        <el-input v-model="formData.enrollmentDeadline" placeholder="请输入报名截止日期" />
      </el-form-item>
      <el-form-item label="最大招生人数" prop="maxStudents">
        <el-input v-model="formData.maxStudents" placeholder="请输入最大招生人数" />
      </el-form-item>
      <el-form-item label="已报名人数（缓存值，以 enrollment 表实际计数为准）" prop="enrolledCount">
        <el-input v-model="formData.enrolledCount" placeholder="请输入已报名人数（缓存值，以 enrollment 表实际计数为准）" />
      </el-form-item>
      <el-form-item label="班期状态（DRAFT草稿/OPEN招生中/PENDING_START待开班/IN_PROGRESS进行中/FINISHED已完成/CANCELLED已取消）" prop="sessionStatus">
        <el-radio-group v-model="formData.sessionStatus">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="班期备注" prop="remark">
        <el-input v-model="formData.remark" placeholder="请输入班期备注" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { CourseSessionApi, CourseSession } from '@/api/maritime/session'

/** 班期管理 表单 */
defineOptions({ name: 'CourseSessionForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  courseId: undefined,
  sessionCode: undefined,
  sessionName: undefined,
  location: undefined,
  durationDays: undefined,
  instructorInfo: undefined,
  startDate: undefined,
  endDate: undefined,
  enrollmentDeadline: undefined,
  maxStudents: undefined,
  enrolledCount: undefined,
  sessionStatus: undefined,
  remark: undefined
})
const formRules = reactive({
  courseId: [{ required: true, message: '课程ID不能为空', trigger: 'blur' }],
  sessionCode: [{ required: true, message: '班期编号（如：2026-06-SH-001）不能为空', trigger: 'blur' }],
  location: [{ required: true, message: '本期上课地点不能为空', trigger: 'blur' }],
  durationDays: [{ required: true, message: '本期课程天数不能为空', trigger: 'blur' }],
  startDate: [{ required: true, message: '开班日期不能为空', trigger: 'blur' }],
  endDate: [{ required: true, message: '结束日期不能为空', trigger: 'blur' }],
  maxStudents: [{ required: true, message: '最大招生人数不能为空', trigger: 'blur' }],
  enrolledCount: [{ required: true, message: '已报名人数（缓存值，以 enrollment 表实际计数为准）不能为空', trigger: 'blur' }],
  sessionStatus: [{ required: true, message: '班期状态（DRAFT草稿/OPEN招生中/PENDING_START待开班/IN_PROGRESS进行中/FINISHED已完成/CANCELLED已取消）不能为空', trigger: 'blur' }]
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await CourseSessionApi.getCourseSession(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as CourseSession
    if (formType.value === 'create') {
      await CourseSessionApi.createCourseSession(data)
      message.success(t('common.createSuccess'))
    } else {
      await CourseSessionApi.updateCourseSession(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    courseId: undefined,
    sessionCode: undefined,
    sessionName: undefined,
    location: undefined,
    durationDays: undefined,
    instructorInfo: undefined,
    startDate: undefined,
    endDate: undefined,
    enrollmentDeadline: undefined,
    maxStudents: undefined,
    enrolledCount: undefined,
    sessionStatus: undefined,
    remark: undefined
  }
  formRef.value?.resetFields()
}
</script>
import request from '@/config/axios'
import type { Dayjs } from 'dayjs';

/** 最新动态信息 */
export interface Announcement {
          id: number; // 公告ID
          title?: string; // 标题
          content: string; // 正文内容（富文本HTML）
          summary: string; // 摘要（列表页展示，1-2行）
          coverImage: string; // 缩略图/封面图URL
          type?: string; // 类型（NEW_COURSE新课/NOTICE公告/ACTIVITY活动/CASE成功案例）
          externalUrl: string; // 外链URL（可选，点击后跳转）
          publishTime: string | Dayjs; // 发布时间（支持定时发布，NULL表示立即发布）
          isTop?: boolean; // 是否置顶（0否 1是，最多3条同时置顶）
          topOrder: number; // 置顶排序序号（置顶时有效，越小越靠前）
          sortOrder?: number; // 非置顶优先级权重（越大越靠前）
          status?: string; // 状态（DRAFT草稿/PUBLISHED已发布）
          viewCount?: number; // 浏览次数
  }

// 最新动态 API
export const AnnouncementApi = {
  // 查询最新动态分页
  getAnnouncementPage: async (params: any) => {
    return await request.get({ url: `/maritime/announcement/page`, params })
  },

  // 查询最新动态详情
  getAnnouncement: async (id: number) => {
    return await request.get({ url: `/maritime/announcement/get?id=` + id })
  },

  // 新增最新动态
  createAnnouncement: async (data: Announcement) => {
    return await request.post({ url: `/maritime/announcement/create`, data })
  },

  // 修改最新动态
  updateAnnouncement: async (data: Announcement) => {
    return await request.put({ url: `/maritime/announcement/update`, data })
  },

  // 删除最新动态
  deleteAnnouncement: async (id: number) => {
    return await request.delete({ url: `/maritime/announcement/delete?id=` + id })
  },

  /** 批量删除最新动态 */
  deleteAnnouncementList: async (ids: number[]) => {
    return await request.delete({ url: `/maritime/announcement/delete-list?ids=${ids.join(',')}` })
  },

  // 导出最新动态 Excel
  exportAnnouncement: async (params) => {
    return await request.download({ url: `/maritime/announcement/export-excel`, params })
  }
}
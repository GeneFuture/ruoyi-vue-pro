<template>
  <ContentWrap>
    <!-- 搜索工作栏 -->
    <el-form
      class="-mb-15px"
      :model="queryParams"
      ref="queryFormRef"
      :inline="true"
      label-width="68px"
    >
      <el-form-item label="标题" prop="title">
        <el-input
          v-model="queryParams.title"
          placeholder="请输入标题"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="摘要（列表页展示，1-2行）" prop="summary">
        <el-input
          v-model="queryParams.summary"
          placeholder="请输入摘要（列表页展示，1-2行）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="类型（NEW_COURSE新课/NOTICE公告/ACTIVITY活动/CASE成功案例）" prop="type">
        <el-select
          v-model="queryParams.type"
          placeholder="请选择类型（NEW_COURSE新课/NOTICE公告/ACTIVITY活动/CASE成功案例）"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="外链URL（可选，点击后跳转）" prop="externalUrl">
        <el-input
          v-model="queryParams.externalUrl"
          placeholder="请输入外链URL（可选，点击后跳转）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="发布时间（支持定时发布，NULL表示立即发布）" prop="publishTime">
        <el-date-picker
          v-model="queryParams.publishTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item label="是否置顶（0否 1是，最多3条同时置顶）" prop="isTop">
        <el-select
          v-model="queryParams.isTop"
          placeholder="请选择是否置顶（0否 1是，最多3条同时置顶）"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="置顶排序序号（置顶时有效，越小越靠前）" prop="topOrder">
        <el-input
          v-model="queryParams.topOrder"
          placeholder="请输入置顶排序序号（置顶时有效，越小越靠前）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="非置顶优先级权重（越大越靠前）" prop="sortOrder">
        <el-input
          v-model="queryParams.sortOrder"
          placeholder="请输入非置顶优先级权重（越大越靠前）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="状态（DRAFT草稿/PUBLISHED已发布）" prop="status">
        <el-select
          v-model="queryParams.status"
          placeholder="请选择状态（DRAFT草稿/PUBLISHED已发布）"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="浏览次数" prop="viewCount">
        <el-input
          v-model="queryParams.viewCount"
          placeholder="请输入浏览次数"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="创建时间" prop="createTime">
        <el-date-picker
          v-model="queryParams.createTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item>
        <el-button @click="handleQuery"><Icon icon="ep:search" class="mr-5px" /> 搜索</el-button>
        <el-button @click="resetQuery"><Icon icon="ep:refresh" class="mr-5px" /> 重置</el-button>
        <el-button
          type="primary"
          plain
          @click="openForm('create')"
          v-hasPermi="['maritime:announcement:create']"
        >
          <Icon icon="ep:plus" class="mr-5px" /> 新增
        </el-button>
        <el-button
          type="success"
          plain
          @click="handleExport"
          :loading="exportLoading"
          v-hasPermi="['maritime:announcement:export']"
        >
          <Icon icon="ep:download" class="mr-5px" /> 导出
        </el-button>
        <el-button
            type="danger"
            plain
            :disabled="isEmpty(checkedIds)"
            @click="handleDeleteBatch"
            v-hasPermi="['maritime:announcement:delete']"
        >
          <Icon icon="ep:delete" class="mr-5px" /> 批量删除
        </el-button>
      </el-form-item>
    </el-form>
  </ContentWrap>

  <!-- 列表 -->
  <ContentWrap>
    <el-table
        row-key="id"
        v-loading="loading"
        :data="list"
        :stripe="true"
        :show-overflow-tooltip="true"
        @selection-change="handleRowCheckboxChange"
    >
    <el-table-column type="selection" width="55" />
      <el-table-column label="公告ID" align="center" prop="id" />
      <el-table-column label="标题" align="center" prop="title" />
      <el-table-column label="正文内容（富文本HTML）" align="center" prop="content" />
      <el-table-column label="摘要（列表页展示，1-2行）" align="center" prop="summary" />
      <el-table-column label="缩略图/封面图URL" align="center" prop="coverImage" />
      <el-table-column label="类型（NEW_COURSE新课/NOTICE公告/ACTIVITY活动/CASE成功案例）" align="center" prop="type" />
      <el-table-column label="外链URL（可选，点击后跳转）" align="center" prop="externalUrl" />
      <el-table-column
        label="发布时间（支持定时发布，NULL表示立即发布）"
        align="center"
        prop="publishTime"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column label="是否置顶（0否 1是，最多3条同时置顶）" align="center" prop="isTop" />
      <el-table-column label="置顶排序序号（置顶时有效，越小越靠前）" align="center" prop="topOrder" />
      <el-table-column label="非置顶优先级权重（越大越靠前）" align="center" prop="sortOrder" />
      <el-table-column label="状态（DRAFT草稿/PUBLISHED已发布）" align="center" prop="status" />
      <el-table-column label="浏览次数" align="center" prop="viewCount" />
      <el-table-column
        label="创建时间"
        align="center"
        prop="createTime"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column label="操作" align="center" min-width="120px">
        <template #default="scope">
          <el-button
            link
            type="primary"
            @click="openForm('update', scope.row.id)"
            v-hasPermi="['maritime:announcement:update']"
          >
            编辑
          </el-button>
          <el-button
            link
            type="danger"
            @click="handleDelete(scope.row.id)"
            v-hasPermi="['maritime:announcement:delete']"
          >
            删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <Pagination
      :total="total"
      v-model:page="queryParams.pageNo"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />
  </ContentWrap>

  <!-- 表单弹窗：添加/修改 -->
  <AnnouncementForm ref="formRef" @success="getList" />
</template>

<script setup lang="ts">
import { isEmpty } from '@/utils/is'
import { dateFormatter } from '@/utils/formatTime'
import download from '@/utils/download'
import { AnnouncementApi, Announcement } from '@/api/maritime/announcement'
import AnnouncementForm from './AnnouncementForm.vue'

/** 最新动态 列表 */
defineOptions({ name: 'Announcement' })

const message = useMessage() // 消息弹窗
const { t } = useI18n() // 国际化

const loading = ref(true) // 列表的加载中
const list = ref<Announcement[]>([]) // 列表的数据
const total = ref(0) // 列表的总页数
const queryParams = reactive({
  pageNo: 1,
  pageSize: 10,
  title: undefined,
  content: undefined,
  summary: undefined,
  coverImage: undefined,
  type: undefined,
  externalUrl: undefined,
  publishTime: [],
  isTop: undefined,
  topOrder: undefined,
  sortOrder: undefined,
  status: undefined,
  viewCount: undefined,
  createTime: []
})
const queryFormRef = ref() // 搜索的表单
const exportLoading = ref(false) // 导出的加载中

/** 查询列表 */
const getList = async () => {
  loading.value = true
  try {
    const data = await AnnouncementApi.getAnnouncementPage(queryParams)
    list.value = data.list
    total.value = data.total
  } finally {
    loading.value = false
  }
}

/** 搜索按钮操作 */
const handleQuery = () => {
  queryParams.pageNo = 1
  getList()
}

/** 重置按钮操作 */
const resetQuery = () => {
  queryFormRef.value.resetFields()
  handleQuery()
}

/** 添加/修改操作 */
const formRef = ref()
const openForm = (type: string, id?: number) => {
  formRef.value.open(type, id)
}

/** 删除按钮操作 */
const handleDelete = async (id: number) => {
  try {
    // 删除的二次确认
    await message.delConfirm()
    // 发起删除
    await AnnouncementApi.deleteAnnouncement(id)
    message.success(t('common.delSuccess'))
    // 刷新列表
    await getList()
  } catch {}
}

/** 批量删除最新动态 */
const handleDeleteBatch = async () => {
  try {
    // 删除的二次确认
    await message.delConfirm()
    await AnnouncementApi.deleteAnnouncementList(checkedIds.value);
    checkedIds.value = [];
    message.success(t('common.delSuccess'))
    await getList();
  } catch {}
}

const checkedIds = ref<number[]>([])
const handleRowCheckboxChange = (records: Announcement[]) => {
  checkedIds.value = records.map((item) => item.id!);
}

/** 导出按钮操作 */
const handleExport = async () => {
  try {
    // 导出的二次确认
    await message.exportConfirm()
    // 发起导出
    exportLoading.value = true
    const data = await AnnouncementApi.exportAnnouncement(queryParams)
    download.excel(data, '最新动态.xls')
  } catch {
  } finally {
    exportLoading.value = false
  }
}

/** 初始化 **/
onMounted(() => {
  getList()
})
</script>
<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="标题" prop="title">
        <el-input v-model="formData.title" placeholder="请输入标题" />
      </el-form-item>
      <el-form-item label="正文内容（富文本HTML）" prop="content">
        <Editor v-model="formData.content" height="150px" />
      </el-form-item>
      <el-form-item label="摘要（列表页展示，1-2行）" prop="summary">
        <el-input v-model="formData.summary" placeholder="请输入摘要（列表页展示，1-2行）" />
      </el-form-item>
      <el-form-item label="缩略图/封面图URL" prop="coverImage">
        <UploadImg v-model="formData.coverImage" />
      </el-form-item>
      <el-form-item label="类型（NEW_COURSE新课/NOTICE公告/ACTIVITY活动/CASE成功案例）" prop="type">
        <el-select v-model="formData.type" placeholder="请选择类型（NEW_COURSE新课/NOTICE公告/ACTIVITY活动/CASE成功案例）">
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="外链URL（可选，点击后跳转）" prop="externalUrl">
        <el-input v-model="formData.externalUrl" placeholder="请输入外链URL（可选，点击后跳转）" />
      </el-form-item>
      <el-form-item label="发布时间（支持定时发布，NULL表示立即发布）" prop="publishTime">
        <el-date-picker
          v-model="formData.publishTime"
          type="date"
          value-format="x"
          placeholder="选择发布时间（支持定时发布，NULL表示立即发布）"
        />
      </el-form-item>
      <el-form-item label="是否置顶（0否 1是，最多3条同时置顶）" prop="isTop">
        <el-radio-group v-model="formData.isTop">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="置顶排序序号（置顶时有效，越小越靠前）" prop="topOrder">
        <el-input v-model="formData.topOrder" placeholder="请输入置顶排序序号（置顶时有效，越小越靠前）" />
      </el-form-item>
      <el-form-item label="非置顶优先级权重（越大越靠前）" prop="sortOrder">
        <el-input v-model="formData.sortOrder" placeholder="请输入非置顶优先级权重（越大越靠前）" />
      </el-form-item>
      <el-form-item label="状态（DRAFT草稿/PUBLISHED已发布）" prop="status">
        <el-radio-group v-model="formData.status">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="浏览次数" prop="viewCount">
        <el-input v-model="formData.viewCount" placeholder="请输入浏览次数" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { AnnouncementApi, Announcement } from '@/api/maritime/announcement'

/** 最新动态 表单 */
defineOptions({ name: 'AnnouncementForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  title: undefined,
  content: undefined,
  summary: undefined,
  coverImage: undefined,
  type: undefined,
  externalUrl: undefined,
  publishTime: undefined,
  isTop: undefined,
  topOrder: undefined,
  sortOrder: undefined,
  status: undefined,
  viewCount: undefined
})
const formRules = reactive({
  title: [{ required: true, message: '标题不能为空', trigger: 'blur' }],
  type: [{ required: true, message: '类型（NEW_COURSE新课/NOTICE公告/ACTIVITY活动/CASE成功案例）不能为空', trigger: 'change' }],
  isTop: [{ required: true, message: '是否置顶（0否 1是，最多3条同时置顶）不能为空', trigger: 'blur' }],
  sortOrder: [{ required: true, message: '非置顶优先级权重（越大越靠前）不能为空', trigger: 'blur' }],
  status: [{ required: true, message: '状态（DRAFT草稿/PUBLISHED已发布）不能为空', trigger: 'blur' }],
  viewCount: [{ required: true, message: '浏览次数不能为空', trigger: 'blur' }]
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await AnnouncementApi.getAnnouncement(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as Announcement
    if (formType.value === 'create') {
      await AnnouncementApi.createAnnouncement(data)
      message.success(t('common.createSuccess'))
    } else {
      await AnnouncementApi.updateAnnouncement(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    title: undefined,
    content: undefined,
    summary: undefined,
    coverImage: undefined,
    type: undefined,
    externalUrl: undefined,
    publishTime: undefined,
    isTop: undefined,
    topOrder: undefined,
    sortOrder: undefined,
    status: undefined,
    viewCount: undefined
  }
  formRef.value?.resetFields()
}
</script>
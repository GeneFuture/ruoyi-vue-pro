<template>
  <ContentWrap>
    <!-- 搜索工作栏 -->
    <el-form
      class="-mb-15px"
      :model="queryParams"
      ref="queryFormRef"
      :inline="true"
      label-width="68px"
    >
      <el-form-item label="报名单号（系统唯一，格式：EN+时间戳）" prop="enrollmentNo">
        <el-input
          v-model="queryParams.enrollmentNo"
          placeholder="请输入报名单号（系统唯一，格式：EN+时间戳）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="学员 member_user.id" prop="memberId">
        <el-input
          v-model="queryParams.memberId"
          placeholder="请输入学员 member_user.id"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="班期ID" prop="sessionId">
        <el-input
          v-model="queryParams.sessionId"
          placeholder="请输入班期ID"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="关联拼团记录（可为空）" prop="grouponRecordId">
        <el-input
          v-model="queryParams.grouponRecordId"
          placeholder="请输入关联拼团记录（可为空）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="推荐人 member_user.id" prop="referredByMemberId">
        <el-input
          v-model="queryParams.referredByMemberId"
          placeholder="请输入推荐人 member_user.id"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="报名时填写的推荐码" prop="referralCodeUsed">
        <el-input
          v-model="queryParams.referralCodeUsed"
          placeholder="请输入报名时填写的推荐码"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="真实姓名" prop="realName">
        <el-input
          v-model="queryParams.realName"
          placeholder="请输入真实姓名"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="身份证号（加密存储，EnrollmentDO 需配置 EncryptTypeHandler）" prop="idCard">
        <el-input
          v-model="queryParams.idCard"
          placeholder="请输入身份证号（加密存储，EnrollmentDO 需配置 EncryptTypeHandler）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="手机号" prop="phone">
        <el-input
          v-model="queryParams.phone"
          placeholder="请输入手机号"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="应缴总金额（元，报名时快照）" prop="totalAmount">
        <el-input
          v-model="queryParams.totalAmount"
          placeholder="请输入应缴总金额（元，报名时快照）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="定金金额快照（元，报名时费用配置的定金值）" prop="depositAmountSnapshot">
        <el-input
          v-model="queryParams.depositAmountSnapshot"
          placeholder="请输入定金金额快照（元，报名时费用配置的定金值）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="尾款金额（元，= total_amount - deposit_amount_snapshot）" prop="balanceAmount">
        <el-input
          v-model="queryParams.balanceAmount"
          placeholder="请输入尾款金额（元，= total_amount - deposit_amount_snapshot）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="已支付金额（元，含定金+已付尾款）" prop="paidAmount">
        <el-input
          v-model="queryParams.paidAmount"
          placeholder="请输入已支付金额（元，含定金+已付尾款）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="尾款截止缴纳日期" prop="balanceDueDate">
        <el-date-picker
          v-model="queryParams.balanceDueDate"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item label="报名状态(PENDING_DEPOSIT/DEPOSITED/PENDING_BALANCE/IN_PROGRESS/COMPLETED/CANCELLED/REFUNDING)" prop="enrollmentStatus">
        <el-select
          v-model="queryParams.enrollmentStatus"
          placeholder="请选择报名状态(PENDING_DEPOSIT/DEPOSITED/PENDING_BALANCE/IN_PROGRESS/COMPLETED/CANCELLED/REFUNDING)"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="是否已获得推荐权（支付定金后=1）" prop="referralRightGranted">
        <el-select
          v-model="queryParams.referralRightGranted"
          placeholder="请选择是否已获得推荐权（支付定金后=1）"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="取消原因" prop="cancelReason">
        <el-input
          v-model="queryParams.cancelReason"
          placeholder="请输入取消原因"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="创建时间" prop="createTime">
        <el-date-picker
          v-model="queryParams.createTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item>
        <el-button @click="handleQuery"><Icon icon="ep:search" class="mr-5px" /> 搜索</el-button>
        <el-button @click="resetQuery"><Icon icon="ep:refresh" class="mr-5px" /> 重置</el-button>
        <el-button
          type="primary"
          plain
          @click="openForm('create')"
          v-hasPermi="['maritime:enrollment:create']"
        >
          <Icon icon="ep:plus" class="mr-5px" /> 新增
        </el-button>
        <el-button
          type="success"
          plain
          @click="handleExport"
          :loading="exportLoading"
          v-hasPermi="['maritime:enrollment:export']"
        >
          <Icon icon="ep:download" class="mr-5px" /> 导出
        </el-button>
        <el-button
            type="danger"
            plain
            :disabled="isEmpty(checkedIds)"
            @click="handleDeleteBatch"
            v-hasPermi="['maritime:enrollment:delete']"
        >
          <Icon icon="ep:delete" class="mr-5px" /> 批量删除
        </el-button>
      </el-form-item>
    </el-form>
  </ContentWrap>

  <!-- 列表 -->
  <ContentWrap>
    <el-table
        row-key="id"
        v-loading="loading"
        :data="list"
        :stripe="true"
        :show-overflow-tooltip="true"
        @selection-change="handleRowCheckboxChange"
    >
    <el-table-column type="selection" width="55" />
      <el-table-column label="报名ID" align="center" prop="id" />
      <el-table-column label="报名单号（系统唯一，格式：EN+时间戳）" align="center" prop="enrollmentNo" />
      <el-table-column label="学员 member_user.id" align="center" prop="memberId" />
      <el-table-column label="班期ID" align="center" prop="sessionId" />
      <el-table-column label="关联拼团记录（可为空）" align="center" prop="grouponRecordId" />
      <el-table-column label="推荐人 member_user.id" align="center" prop="referredByMemberId" />
      <el-table-column label="报名时填写的推荐码" align="center" prop="referralCodeUsed" />
      <el-table-column label="真实姓名" align="center" prop="realName" />
      <el-table-column label="身份证号（加密存储，EnrollmentDO 需配置 EncryptTypeHandler）" align="center" prop="idCard" />
      <el-table-column label="手机号" align="center" prop="phone" />
      <el-table-column label="应缴总金额（元，报名时快照）" align="center" prop="totalAmount" />
      <el-table-column label="定金金额快照（元，报名时费用配置的定金值）" align="center" prop="depositAmountSnapshot" />
      <el-table-column label="尾款金额（元，= total_amount - deposit_amount_snapshot）" align="center" prop="balanceAmount" />
      <el-table-column label="已支付金额（元，含定金+已付尾款）" align="center" prop="paidAmount" />
      <el-table-column label="尾款截止缴纳日期" align="center" prop="balanceDueDate" />
      <el-table-column label="报名状态(PENDING_DEPOSIT/DEPOSITED/PENDING_BALANCE/IN_PROGRESS/COMPLETED/CANCELLED/REFUNDING)" align="center" prop="enrollmentStatus" />
      <el-table-column label="是否已获得推荐权（支付定金后=1）" align="center" prop="referralRightGranted" />
      <el-table-column label="取消原因" align="center" prop="cancelReason" />
      <el-table-column
        label="创建时间"
        align="center"
        prop="createTime"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column label="操作" align="center" min-width="120px">
        <template #default="scope">
          <el-button
            link
            type="primary"
            @click="openForm('update', scope.row.id)"
            v-hasPermi="['maritime:enrollment:update']"
          >
            编辑
          </el-button>
          <el-button
            link
            type="danger"
            @click="handleDelete(scope.row.id)"
            v-hasPermi="['maritime:enrollment:delete']"
          >
            删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <Pagination
      :total="total"
      v-model:page="queryParams.pageNo"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />
  </ContentWrap>

  <!-- 表单弹窗：添加/修改 -->
  <EnrollmentForm ref="formRef" @success="getList" />
</template>

<script setup lang="ts">
import { isEmpty } from '@/utils/is'
import { dateFormatter } from '@/utils/formatTime'
import download from '@/utils/download'
import { EnrollmentApi, Enrollment } from '@/api/maritime/enrollment'
import EnrollmentForm from './EnrollmentForm.vue'

/** 报名管理 列表 */
defineOptions({ name: 'Enrollment' })

const message = useMessage() // 消息弹窗
const { t } = useI18n() // 国际化

const loading = ref(true) // 列表的加载中
const list = ref<Enrollment[]>([]) // 列表的数据
const total = ref(0) // 列表的总页数
const queryParams = reactive({
  pageNo: 1,
  pageSize: 10,
  enrollmentNo: undefined,
  memberId: undefined,
  sessionId: undefined,
  grouponRecordId: undefined,
  referredByMemberId: undefined,
  referralCodeUsed: undefined,
  realName: undefined,
  idCard: undefined,
  phone: undefined,
  totalAmount: undefined,
  depositAmountSnapshot: undefined,
  balanceAmount: undefined,
  paidAmount: undefined,
  balanceDueDate: [],
  enrollmentStatus: undefined,
  referralRightGranted: undefined,
  cancelReason: undefined,
  createTime: []
})
const queryFormRef = ref() // 搜索的表单
const exportLoading = ref(false) // 导出的加载中

/** 查询列表 */
const getList = async () => {
  loading.value = true
  try {
    const data = await EnrollmentApi.getEnrollmentPage(queryParams)
    list.value = data.list
    total.value = data.total
  } finally {
    loading.value = false
  }
}

/** 搜索按钮操作 */
const handleQuery = () => {
  queryParams.pageNo = 1
  getList()
}

/** 重置按钮操作 */
const resetQuery = () => {
  queryFormRef.value.resetFields()
  handleQuery()
}

/** 添加/修改操作 */
const formRef = ref()
const openForm = (type: string, id?: number) => {
  formRef.value.open(type, id)
}

/** 删除按钮操作 */
const handleDelete = async (id: number) => {
  try {
    // 删除的二次确认
    await message.delConfirm()
    // 发起删除
    await EnrollmentApi.deleteEnrollment(id)
    message.success(t('common.delSuccess'))
    // 刷新列表
    await getList()
  } catch {}
}

/** 批量删除报名管理 */
const handleDeleteBatch = async () => {
  try {
    // 删除的二次确认
    await message.delConfirm()
    await EnrollmentApi.deleteEnrollmentList(checkedIds.value);
    checkedIds.value = [];
    message.success(t('common.delSuccess'))
    await getList();
  } catch {}
}

const checkedIds = ref<number[]>([])
const handleRowCheckboxChange = (records: Enrollment[]) => {
  checkedIds.value = records.map((item) => item.id!);
}

/** 导出按钮操作 */
const handleExport = async () => {
  try {
    // 导出的二次确认
    await message.exportConfirm()
    // 发起导出
    exportLoading.value = true
    const data = await EnrollmentApi.exportEnrollment(queryParams)
    download.excel(data, '报名管理.xls')
  } catch {
  } finally {
    exportLoading.value = false
  }
}

/** 初始化 **/
onMounted(() => {
  getList()
})
</script>
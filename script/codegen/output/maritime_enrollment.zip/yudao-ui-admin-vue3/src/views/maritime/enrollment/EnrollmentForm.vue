<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="报名单号（系统唯一，格式：EN+时间戳）" prop="enrollmentNo">
        <el-input v-model="formData.enrollmentNo" placeholder="请输入报名单号（系统唯一，格式：EN+时间戳）" />
      </el-form-item>
      <el-form-item label="学员 member_user.id" prop="memberId">
        <el-input v-model="formData.memberId" placeholder="请输入学员 member_user.id" />
      </el-form-item>
      <el-form-item label="班期ID" prop="sessionId">
        <el-input v-model="formData.sessionId" placeholder="请输入班期ID" />
      </el-form-item>
      <el-form-item label="关联拼团记录（可为空）" prop="grouponRecordId">
        <el-input v-model="formData.grouponRecordId" placeholder="请输入关联拼团记录（可为空）" />
      </el-form-item>
      <el-form-item label="推荐人 member_user.id" prop="referredByMemberId">
        <el-input v-model="formData.referredByMemberId" placeholder="请输入推荐人 member_user.id" />
      </el-form-item>
      <el-form-item label="报名时填写的推荐码" prop="referralCodeUsed">
        <el-input v-model="formData.referralCodeUsed" placeholder="请输入报名时填写的推荐码" />
      </el-form-item>
      <el-form-item label="真实姓名" prop="realName">
        <el-input v-model="formData.realName" placeholder="请输入真实姓名" />
      </el-form-item>
      <el-form-item label="身份证号（加密存储，EnrollmentDO 需配置 EncryptTypeHandler）" prop="idCard">
        <el-input v-model="formData.idCard" placeholder="请输入身份证号（加密存储，EnrollmentDO 需配置 EncryptTypeHandler）" />
      </el-form-item>
      <el-form-item label="手机号" prop="phone">
        <el-input v-model="formData.phone" placeholder="请输入手机号" />
      </el-form-item>
      <el-form-item label="应缴总金额（元，报名时快照）" prop="totalAmount">
        <el-input v-model="formData.totalAmount" placeholder="请输入应缴总金额（元，报名时快照）" />
      </el-form-item>
      <el-form-item label="定金金额快照（元，报名时费用配置的定金值）" prop="depositAmountSnapshot">
        <el-input v-model="formData.depositAmountSnapshot" placeholder="请输入定金金额快照（元，报名时费用配置的定金值）" />
      </el-form-item>
      <el-form-item label="尾款金额（元，= total_amount - deposit_amount_snapshot）" prop="balanceAmount">
        <el-input v-model="formData.balanceAmount" placeholder="请输入尾款金额（元，= total_amount - deposit_amount_snapshot）" />
      </el-form-item>
      <el-form-item label="已支付金额（元，含定金+已付尾款）" prop="paidAmount">
        <el-input v-model="formData.paidAmount" placeholder="请输入已支付金额（元，含定金+已付尾款）" />
      </el-form-item>
      <el-form-item label="尾款截止缴纳日期" prop="balanceDueDate">
        <el-date-picker
          v-model="formData.balanceDueDate"
          type="date"
          value-format="x"
          placeholder="选择尾款截止缴纳日期"
        />
      </el-form-item>
      <el-form-item label="报名状态(PENDING_DEPOSIT/DEPOSITED/PENDING_BALANCE/IN_PROGRESS/COMPLETED/CANCELLED/REFUNDING)" prop="enrollmentStatus">
        <el-radio-group v-model="formData.enrollmentStatus">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="是否已获得推荐权（支付定金后=1）" prop="referralRightGranted">
        <el-radio-group v-model="formData.referralRightGranted">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="取消原因" prop="cancelReason">
        <el-input v-model="formData.cancelReason" placeholder="请输入取消原因" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { EnrollmentApi, Enrollment } from '@/api/maritime/enrollment'

/** 报名管理 表单 */
defineOptions({ name: 'EnrollmentForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  enrollmentNo: undefined,
  memberId: undefined,
  sessionId: undefined,
  grouponRecordId: undefined,
  referredByMemberId: undefined,
  referralCodeUsed: undefined,
  realName: undefined,
  idCard: undefined,
  phone: undefined,
  totalAmount: undefined,
  depositAmountSnapshot: undefined,
  balanceAmount: undefined,
  paidAmount: undefined,
  balanceDueDate: undefined,
  enrollmentStatus: undefined,
  referralRightGranted: undefined,
  cancelReason: undefined
})
const formRules = reactive({
  enrollmentNo: [{ required: true, message: '报名单号（系统唯一，格式：EN+时间戳）不能为空', trigger: 'blur' }],
  memberId: [{ required: true, message: '学员 member_user.id不能为空', trigger: 'blur' }],
  sessionId: [{ required: true, message: '班期ID不能为空', trigger: 'blur' }],
  realName: [{ required: true, message: '真实姓名不能为空', trigger: 'blur' }],
  idCard: [{ required: true, message: '身份证号（加密存储，EnrollmentDO 需配置 EncryptTypeHandler）不能为空', trigger: 'blur' }],
  phone: [{ required: true, message: '手机号不能为空', trigger: 'blur' }],
  totalAmount: [{ required: true, message: '应缴总金额（元，报名时快照）不能为空', trigger: 'blur' }],
  depositAmountSnapshot: [{ required: true, message: '定金金额快照（元，报名时费用配置的定金值）不能为空', trigger: 'blur' }],
  balanceAmount: [{ required: true, message: '尾款金额（元，= total_amount - deposit_amount_snapshot）不能为空', trigger: 'blur' }],
  paidAmount: [{ required: true, message: '已支付金额（元，含定金+已付尾款）不能为空', trigger: 'blur' }],
  enrollmentStatus: [{ required: true, message: '报名状态(PENDING_DEPOSIT/DEPOSITED/PENDING_BALANCE/IN_PROGRESS/COMPLETED/CANCELLED/REFUNDING)不能为空', trigger: 'blur' }],
  referralRightGranted: [{ required: true, message: '是否已获得推荐权（支付定金后=1）不能为空', trigger: 'blur' }]
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await EnrollmentApi.getEnrollment(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as Enrollment
    if (formType.value === 'create') {
      await EnrollmentApi.createEnrollment(data)
      message.success(t('common.createSuccess'))
    } else {
      await EnrollmentApi.updateEnrollment(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    enrollmentNo: undefined,
    memberId: undefined,
    sessionId: undefined,
    grouponRecordId: undefined,
    referredByMemberId: undefined,
    referralCodeUsed: undefined,
    realName: undefined,
    idCard: undefined,
    phone: undefined,
    totalAmount: undefined,
    depositAmountSnapshot: undefined,
    balanceAmount: undefined,
    paidAmount: undefined,
    balanceDueDate: undefined,
    enrollmentStatus: undefined,
    referralRightGranted: undefined,
    cancelReason: undefined
  }
  formRef.value?.resetFields()
}
</script>
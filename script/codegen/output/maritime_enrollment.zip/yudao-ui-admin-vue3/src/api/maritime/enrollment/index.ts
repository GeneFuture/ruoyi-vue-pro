import request from '@/config/axios'
import type { Dayjs } from 'dayjs';

/** 报名管理信息 */
export interface Enrollment {
          id: number; // 报名ID
          enrollmentNo?: string; // 报名单号（系统唯一，格式：EN+时间戳）
          memberId?: number; // 学员 member_user.id
          sessionId?: number; // 班期ID
          grouponRecordId: number; // 关联拼团记录（可为空）
          referredByMemberId: number; // 推荐人 member_user.id
          referralCodeUsed: string; // 报名时填写的推荐码
          realName?: string; // 真实姓名
          idCard?: string; // 身份证号（加密存储，EnrollmentDO 需配置 EncryptTypeHandler）
          phone?: string; // 手机号
          totalAmount?: number; // 应缴总金额（元，报名时快照）
          depositAmountSnapshot?: number; // 定金金额快照（元，报名时费用配置的定金值）
          balanceAmount?: number; // 尾款金额（元，= total_amount - deposit_amount_snapshot）
          paidAmount?: number; // 已支付金额（元，含定金+已付尾款）
          balanceDueDate: string | Dayjs; // 尾款截止缴纳日期
          enrollmentStatus?: string; // 报名状态(PENDING_DEPOSIT/DEPOSITED/PENDING_BALANCE/IN_PROGRESS/COMPLETED/CANCELLED/REFUNDING)
          referralRightGranted?: boolean; // 是否已获得推荐权（支付定金后=1）
          cancelReason: string; // 取消原因
  }

// 报名管理 API
export const EnrollmentApi = {
  // 查询报名管理分页
  getEnrollmentPage: async (params: any) => {
    return await request.get({ url: `/maritime/enrollment/page`, params })
  },

  // 查询报名管理详情
  getEnrollment: async (id: number) => {
    return await request.get({ url: `/maritime/enrollment/get?id=` + id })
  },

  // 新增报名管理
  createEnrollment: async (data: Enrollment) => {
    return await request.post({ url: `/maritime/enrollment/create`, data })
  },

  // 修改报名管理
  updateEnrollment: async (data: Enrollment) => {
    return await request.put({ url: `/maritime/enrollment/update`, data })
  },

  // 删除报名管理
  deleteEnrollment: async (id: number) => {
    return await request.delete({ url: `/maritime/enrollment/delete?id=` + id })
  },

  /** 批量删除报名管理 */
  deleteEnrollmentList: async (ids: number[]) => {
    return await request.delete({ url: `/maritime/enrollment/delete-list?ids=${ids.join(',')}` })
  },

  // 导出报名管理 Excel
  exportEnrollment: async (params) => {
    return await request.download({ url: `/maritime/enrollment/export-excel`, params })
  }
}
<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="接收人 member_user.id" prop="memberId">
        <el-input v-model="formData.memberId" placeholder="请输入接收人 member_user.id" />
      </el-form-item>
      <el-form-item label="消息类型（ORDER=订单类/GROUPON=拼团类/COMMISSION=佣金类/SYSTEM=系统公告）" prop="type">
        <el-select v-model="formData.type" placeholder="请选择消息类型（ORDER=订单类/GROUPON=拼团类/COMMISSION=佣金类/SYSTEM=系统公告）">
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="消息标题" prop="title">
        <el-input v-model="formData.title" placeholder="请输入消息标题" />
      </el-form-item>
      <el-form-item label="消息正文" prop="content">
        <Editor v-model="formData.content" height="150px" />
      </el-form-item>
      <el-form-item label="关联业务ID（enrollment_id/commission_record_id等，可为空）" prop="relatedId">
        <el-input v-model="formData.relatedId" placeholder="请输入关联业务ID（enrollment_id/commission_record_id等，可为空）" />
      </el-form-item>
      <el-form-item label="关联业务类型（ENROLLMENT/COMMISSION/GROUPON）" prop="relatedType">
        <el-select v-model="formData.relatedType" placeholder="请选择关联业务类型（ENROLLMENT/COMMISSION/GROUPON）">
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="是否已读（0未读 1已读）" prop="isRead">
        <el-radio-group v-model="formData.isRead">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="阅读时间" prop="readTime">
        <el-date-picker
          v-model="formData.readTime"
          type="date"
          value-format="x"
          placeholder="选择阅读时间"
        />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { UserMessageApi, UserMessage } from '@/api/maritime/userMessage'

/** 站内消息 表单 */
defineOptions({ name: 'UserMessageForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  memberId: undefined,
  type: undefined,
  title: undefined,
  content: undefined,
  relatedId: undefined,
  relatedType: undefined,
  isRead: undefined,
  readTime: undefined
})
const formRules = reactive({
  memberId: [{ required: true, message: '接收人 member_user.id不能为空', trigger: 'blur' }],
  type: [{ required: true, message: '消息类型（ORDER=订单类/GROUPON=拼团类/COMMISSION=佣金类/SYSTEM=系统公告）不能为空', trigger: 'change' }],
  title: [{ required: true, message: '消息标题不能为空', trigger: 'blur' }],
  isRead: [{ required: true, message: '是否已读（0未读 1已读）不能为空', trigger: 'blur' }]
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await UserMessageApi.getUserMessage(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as UserMessage
    if (formType.value === 'create') {
      await UserMessageApi.createUserMessage(data)
      message.success(t('common.createSuccess'))
    } else {
      await UserMessageApi.updateUserMessage(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    memberId: undefined,
    type: undefined,
    title: undefined,
    content: undefined,
    relatedId: undefined,
    relatedType: undefined,
    isRead: undefined,
    readTime: undefined
  }
  formRef.value?.resetFields()
}
</script>
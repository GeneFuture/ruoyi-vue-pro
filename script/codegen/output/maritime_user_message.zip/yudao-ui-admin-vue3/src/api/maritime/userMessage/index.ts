import request from '@/config/axios'
import type { Dayjs } from 'dayjs';

/** 站内消息信息 */
export interface UserMessage {
          id: number; // 消息ID
          memberId?: number; // 接收人 member_user.id
          type?: string; // 消息类型（ORDER=订单类/GROUPON=拼团类/COMMISSION=佣金类/SYSTEM=系统公告）
          title?: string; // 消息标题
          content: string; // 消息正文
          relatedId: number; // 关联业务ID（enrollment_id/commission_record_id等，可为空）
          relatedType: string; // 关联业务类型（ENROLLMENT/COMMISSION/GROUPON）
          isRead?: boolean; // 是否已读（0未读 1已读）
          readTime: string | Dayjs; // 阅读时间
  }

// 站内消息 API
export const UserMessageApi = {
  // 查询站内消息分页
  getUserMessagePage: async (params: any) => {
    return await request.get({ url: `/maritime/user-message/page`, params })
  },

  // 查询站内消息详情
  getUserMessage: async (id: number) => {
    return await request.get({ url: `/maritime/user-message/get?id=` + id })
  },

  // 新增站内消息
  createUserMessage: async (data: UserMessage) => {
    return await request.post({ url: `/maritime/user-message/create`, data })
  },

  // 修改站内消息
  updateUserMessage: async (data: UserMessage) => {
    return await request.put({ url: `/maritime/user-message/update`, data })
  },

  // 删除站内消息
  deleteUserMessage: async (id: number) => {
    return await request.delete({ url: `/maritime/user-message/delete?id=` + id })
  },

  /** 批量删除站内消息 */
  deleteUserMessageList: async (ids: number[]) => {
    return await request.delete({ url: `/maritime/user-message/delete-list?ids=${ids.join(',')}` })
  },

  // 导出站内消息 Excel
  exportUserMessage: async (params) => {
    return await request.download({ url: `/maritime/user-message/export-excel`, params })
  }
}
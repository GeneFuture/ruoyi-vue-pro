import request from '@/config/axios'
import type { Dayjs } from 'dayjs';

/** 佣金记录信息 */
export interface CommissionRecord {
          id: number; // 佣金记录ID
          referrerMemberId?: number; // 推荐人
          referredEnrollmentId?: number; // 被推荐人的报名ID
          sessionId?: number; // 班期ID
          commissionAmount?: number; // 佣金金额（元）
          commissionStatus?: string; // 状态(WAITING_FOR_CLASS/FROZEN/PENDING_REVIEW/REVIEWING/PENDING_PAYOUT/PAYING/PAID/REJECTED/FAILED/MANUALLY_PAID)
          expectedSettleDate?: string | Dayjs; // 预计结算日期（= 开课日期 + 7天）
          isRiskFlagged?: boolean; // 是否风控标记
          riskCheckResult: string; // 风控检查详情（JSON）
          triggerTime?: string | Dayjs; // 触发时间（全款支付时）
          settleCheckTime: string | Dayjs; // 开课7天检查执行时间
          approveTime: string | Dayjs; // 审核通过时间
          approverId: number; // 审核人
          approveRemark: string; // 审核备注
          payoutTime: string | Dayjs; // 发放时间
          payTransferId: number; // ruoyi pay_transfer.id（调用 PayTransferApi 后填写）
          failReason: string; // 发放失败原因
          retryCount?: number; // 自动发放失败后已重试次数
  }

// 佣金记录 API
export const CommissionRecordApi = {
  // 查询佣金记录分页
  getCommissionRecordPage: async (params: any) => {
    return await request.get({ url: `/maritime/commission-record/page`, params })
  },

  // 查询佣金记录详情
  getCommissionRecord: async (id: number) => {
    return await request.get({ url: `/maritime/commission-record/get?id=` + id })
  },

  // 新增佣金记录
  createCommissionRecord: async (data: CommissionRecord) => {
    return await request.post({ url: `/maritime/commission-record/create`, data })
  },

  // 修改佣金记录
  updateCommissionRecord: async (data: CommissionRecord) => {
    return await request.put({ url: `/maritime/commission-record/update`, data })
  },

  // 删除佣金记录
  deleteCommissionRecord: async (id: number) => {
    return await request.delete({ url: `/maritime/commission-record/delete?id=` + id })
  },

  /** 批量删除佣金记录 */
  deleteCommissionRecordList: async (ids: number[]) => {
    return await request.delete({ url: `/maritime/commission-record/delete-list?ids=${ids.join(',')}` })
  },

  // 导出佣金记录 Excel
  exportCommissionRecord: async (params) => {
    return await request.download({ url: `/maritime/commission-record/export-excel`, params })
  }
}
<template>
  <ContentWrap>
    <!-- 搜索工作栏 -->
    <el-form
      class="-mb-15px"
      :model="queryParams"
      ref="queryFormRef"
      :inline="true"
      label-width="68px"
    >
      <el-form-item label="推荐人" prop="referrerMemberId">
        <el-input
          v-model="queryParams.referrerMemberId"
          placeholder="请输入推荐人"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="被推荐人的报名ID" prop="referredEnrollmentId">
        <el-input
          v-model="queryParams.referredEnrollmentId"
          placeholder="请输入被推荐人的报名ID"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="班期ID" prop="sessionId">
        <el-input
          v-model="queryParams.sessionId"
          placeholder="请输入班期ID"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="佣金金额（元）" prop="commissionAmount">
        <el-input
          v-model="queryParams.commissionAmount"
          placeholder="请输入佣金金额（元）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="状态(WAITING_FOR_CLASS/FROZEN/PENDING_REVIEW/REVIEWING/PENDING_PAYOUT/PAYING/PAID/REJECTED/FAILED/MANUALLY_PAID)" prop="commissionStatus">
        <el-select
          v-model="queryParams.commissionStatus"
          placeholder="请选择状态(WAITING_FOR_CLASS/FROZEN/PENDING_REVIEW/REVIEWING/PENDING_PAYOUT/PAYING/PAID/REJECTED/FAILED/MANUALLY_PAID)"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="预计结算日期（= 开课日期 + 7天）" prop="expectedSettleDate">
        <el-date-picker
          v-model="queryParams.expectedSettleDate"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item label="是否风控标记" prop="isRiskFlagged">
        <el-select
          v-model="queryParams.isRiskFlagged"
          placeholder="请选择是否风控标记"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="风控检查详情（JSON）" prop="riskCheckResult">
        <el-input
          v-model="queryParams.riskCheckResult"
          placeholder="请输入风控检查详情（JSON）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="触发时间（全款支付时）" prop="triggerTime">
        <el-date-picker
          v-model="queryParams.triggerTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item label="开课7天检查执行时间" prop="settleCheckTime">
        <el-date-picker
          v-model="queryParams.settleCheckTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item label="审核通过时间" prop="approveTime">
        <el-date-picker
          v-model="queryParams.approveTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item label="审核人" prop="approverId">
        <el-input
          v-model="queryParams.approverId"
          placeholder="请输入审核人"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="审核备注" prop="approveRemark">
        <el-input
          v-model="queryParams.approveRemark"
          placeholder="请输入审核备注"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="发放时间" prop="payoutTime">
        <el-date-picker
          v-model="queryParams.payoutTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item label="ruoyi pay_transfer.id（调用 PayTransferApi 后填写）" prop="payTransferId">
        <el-input
          v-model="queryParams.payTransferId"
          placeholder="请输入ruoyi pay_transfer.id（调用 PayTransferApi 后填写）"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="发放失败原因" prop="failReason">
        <el-input
          v-model="queryParams.failReason"
          placeholder="请输入发放失败原因"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="自动发放失败后已重试次数" prop="retryCount">
        <el-input
          v-model="queryParams.retryCount"
          placeholder="请输入自动发放失败后已重试次数"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="创建时间" prop="createTime">
        <el-date-picker
          v-model="queryParams.createTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item>
        <el-button @click="handleQuery"><Icon icon="ep:search" class="mr-5px" /> 搜索</el-button>
        <el-button @click="resetQuery"><Icon icon="ep:refresh" class="mr-5px" /> 重置</el-button>
        <el-button
          type="primary"
          plain
          @click="openForm('create')"
          v-hasPermi="['maritime:commission-record:create']"
        >
          <Icon icon="ep:plus" class="mr-5px" /> 新增
        </el-button>
        <el-button
          type="success"
          plain
          @click="handleExport"
          :loading="exportLoading"
          v-hasPermi="['maritime:commission-record:export']"
        >
          <Icon icon="ep:download" class="mr-5px" /> 导出
        </el-button>
        <el-button
            type="danger"
            plain
            :disabled="isEmpty(checkedIds)"
            @click="handleDeleteBatch"
            v-hasPermi="['maritime:commission-record:delete']"
        >
          <Icon icon="ep:delete" class="mr-5px" /> 批量删除
        </el-button>
      </el-form-item>
    </el-form>
  </ContentWrap>

  <!-- 列表 -->
  <ContentWrap>
    <el-table
        row-key="id"
        v-loading="loading"
        :data="list"
        :stripe="true"
        :show-overflow-tooltip="true"
        @selection-change="handleRowCheckboxChange"
    >
    <el-table-column type="selection" width="55" />
      <el-table-column label="佣金记录ID" align="center" prop="id" />
      <el-table-column label="推荐人" align="center" prop="referrerMemberId" />
      <el-table-column label="被推荐人的报名ID" align="center" prop="referredEnrollmentId" />
      <el-table-column label="班期ID" align="center" prop="sessionId" />
      <el-table-column label="佣金金额（元）" align="center" prop="commissionAmount" />
      <el-table-column label="状态(WAITING_FOR_CLASS/FROZEN/PENDING_REVIEW/REVIEWING/PENDING_PAYOUT/PAYING/PAID/REJECTED/FAILED/MANUALLY_PAID)" align="center" prop="commissionStatus" />
      <el-table-column label="预计结算日期（= 开课日期 + 7天）" align="center" prop="expectedSettleDate" />
      <el-table-column label="是否风控标记" align="center" prop="isRiskFlagged" />
      <el-table-column label="风控检查详情（JSON）" align="center" prop="riskCheckResult" />
      <el-table-column
        label="触发时间（全款支付时）"
        align="center"
        prop="triggerTime"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column
        label="开课7天检查执行时间"
        align="center"
        prop="settleCheckTime"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column
        label="审核通过时间"
        align="center"
        prop="approveTime"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column label="审核人" align="center" prop="approverId" />
      <el-table-column label="审核备注" align="center" prop="approveRemark" />
      <el-table-column
        label="发放时间"
        align="center"
        prop="payoutTime"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column label="ruoyi pay_transfer.id（调用 PayTransferApi 后填写）" align="center" prop="payTransferId" />
      <el-table-column label="发放失败原因" align="center" prop="failReason" />
      <el-table-column label="自动发放失败后已重试次数" align="center" prop="retryCount" />
      <el-table-column
        label="创建时间"
        align="center"
        prop="createTime"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column label="操作" align="center" min-width="120px">
        <template #default="scope">
          <el-button
            link
            type="primary"
            @click="openForm('update', scope.row.id)"
            v-hasPermi="['maritime:commission-record:update']"
          >
            编辑
          </el-button>
          <el-button
            link
            type="danger"
            @click="handleDelete(scope.row.id)"
            v-hasPermi="['maritime:commission-record:delete']"
          >
            删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <Pagination
      :total="total"
      v-model:page="queryParams.pageNo"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />
  </ContentWrap>

  <!-- 表单弹窗：添加/修改 -->
  <CommissionRecordForm ref="formRef" @success="getList" />
</template>

<script setup lang="ts">
import { isEmpty } from '@/utils/is'
import { dateFormatter } from '@/utils/formatTime'
import download from '@/utils/download'
import { CommissionRecordApi, CommissionRecord } from '@/api/maritime/commissionRecord'
import CommissionRecordForm from './CommissionRecordForm.vue'

/** 佣金记录 列表 */
defineOptions({ name: 'CommissionRecord' })

const message = useMessage() // 消息弹窗
const { t } = useI18n() // 国际化

const loading = ref(true) // 列表的加载中
const list = ref<CommissionRecord[]>([]) // 列表的数据
const total = ref(0) // 列表的总页数
const queryParams = reactive({
  pageNo: 1,
  pageSize: 10,
  referrerMemberId: undefined,
  referredEnrollmentId: undefined,
  sessionId: undefined,
  commissionAmount: undefined,
  commissionStatus: undefined,
  expectedSettleDate: [],
  isRiskFlagged: undefined,
  riskCheckResult: undefined,
  triggerTime: [],
  settleCheckTime: [],
  approveTime: [],
  approverId: undefined,
  approveRemark: undefined,
  payoutTime: [],
  payTransferId: undefined,
  failReason: undefined,
  retryCount: undefined,
  createTime: []
})
const queryFormRef = ref() // 搜索的表单
const exportLoading = ref(false) // 导出的加载中

/** 查询列表 */
const getList = async () => {
  loading.value = true
  try {
    const data = await CommissionRecordApi.getCommissionRecordPage(queryParams)
    list.value = data.list
    total.value = data.total
  } finally {
    loading.value = false
  }
}

/** 搜索按钮操作 */
const handleQuery = () => {
  queryParams.pageNo = 1
  getList()
}

/** 重置按钮操作 */
const resetQuery = () => {
  queryFormRef.value.resetFields()
  handleQuery()
}

/** 添加/修改操作 */
const formRef = ref()
const openForm = (type: string, id?: number) => {
  formRef.value.open(type, id)
}

/** 删除按钮操作 */
const handleDelete = async (id: number) => {
  try {
    // 删除的二次确认
    await message.delConfirm()
    // 发起删除
    await CommissionRecordApi.deleteCommissionRecord(id)
    message.success(t('common.delSuccess'))
    // 刷新列表
    await getList()
  } catch {}
}

/** 批量删除佣金记录 */
const handleDeleteBatch = async () => {
  try {
    // 删除的二次确认
    await message.delConfirm()
    await CommissionRecordApi.deleteCommissionRecordList(checkedIds.value);
    checkedIds.value = [];
    message.success(t('common.delSuccess'))
    await getList();
  } catch {}
}

const checkedIds = ref<number[]>([])
const handleRowCheckboxChange = (records: CommissionRecord[]) => {
  checkedIds.value = records.map((item) => item.id!);
}

/** 导出按钮操作 */
const handleExport = async () => {
  try {
    // 导出的二次确认
    await message.exportConfirm()
    // 发起导出
    exportLoading.value = true
    const data = await CommissionRecordApi.exportCommissionRecord(queryParams)
    download.excel(data, '佣金记录.xls')
  } catch {
  } finally {
    exportLoading.value = false
  }
}

/** 初始化 **/
onMounted(() => {
  getList()
})
</script>
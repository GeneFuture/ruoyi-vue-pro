<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="推荐人" prop="referrerMemberId">
        <el-input v-model="formData.referrerMemberId" placeholder="请输入推荐人" />
      </el-form-item>
      <el-form-item label="被推荐人的报名ID" prop="referredEnrollmentId">
        <el-input v-model="formData.referredEnrollmentId" placeholder="请输入被推荐人的报名ID" />
      </el-form-item>
      <el-form-item label="班期ID" prop="sessionId">
        <el-input v-model="formData.sessionId" placeholder="请输入班期ID" />
      </el-form-item>
      <el-form-item label="佣金金额（元）" prop="commissionAmount">
        <el-input v-model="formData.commissionAmount" placeholder="请输入佣金金额（元）" />
      </el-form-item>
      <el-form-item label="状态(WAITING_FOR_CLASS/FROZEN/PENDING_REVIEW/REVIEWING/PENDING_PAYOUT/PAYING/PAID/REJECTED/FAILED/MANUALLY_PAID)" prop="commissionStatus">
        <el-radio-group v-model="formData.commissionStatus">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="预计结算日期（= 开课日期 + 7天）" prop="expectedSettleDate">
        <el-date-picker
          v-model="formData.expectedSettleDate"
          type="date"
          value-format="x"
          placeholder="选择预计结算日期（= 开课日期 + 7天）"
        />
      </el-form-item>
      <el-form-item label="是否风控标记" prop="isRiskFlagged">
        <el-radio-group v-model="formData.isRiskFlagged">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="风控检查详情（JSON）" prop="riskCheckResult">
        <el-input v-model="formData.riskCheckResult" placeholder="请输入风控检查详情（JSON）" />
      </el-form-item>
      <el-form-item label="触发时间（全款支付时）" prop="triggerTime">
        <el-date-picker
          v-model="formData.triggerTime"
          type="date"
          value-format="x"
          placeholder="选择触发时间（全款支付时）"
        />
      </el-form-item>
      <el-form-item label="开课7天检查执行时间" prop="settleCheckTime">
        <el-date-picker
          v-model="formData.settleCheckTime"
          type="date"
          value-format="x"
          placeholder="选择开课7天检查执行时间"
        />
      </el-form-item>
      <el-form-item label="审核通过时间" prop="approveTime">
        <el-date-picker
          v-model="formData.approveTime"
          type="date"
          value-format="x"
          placeholder="选择审核通过时间"
        />
      </el-form-item>
      <el-form-item label="审核人" prop="approverId">
        <el-input v-model="formData.approverId" placeholder="请输入审核人" />
      </el-form-item>
      <el-form-item label="审核备注" prop="approveRemark">
        <el-input v-model="formData.approveRemark" placeholder="请输入审核备注" />
      </el-form-item>
      <el-form-item label="发放时间" prop="payoutTime">
        <el-date-picker
          v-model="formData.payoutTime"
          type="date"
          value-format="x"
          placeholder="选择发放时间"
        />
      </el-form-item>
      <el-form-item label="ruoyi pay_transfer.id（调用 PayTransferApi 后填写）" prop="payTransferId">
        <el-input v-model="formData.payTransferId" placeholder="请输入ruoyi pay_transfer.id（调用 PayTransferApi 后填写）" />
      </el-form-item>
      <el-form-item label="发放失败原因" prop="failReason">
        <el-input v-model="formData.failReason" placeholder="请输入发放失败原因" />
      </el-form-item>
      <el-form-item label="自动发放失败后已重试次数" prop="retryCount">
        <el-input v-model="formData.retryCount" placeholder="请输入自动发放失败后已重试次数" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { CommissionRecordApi, CommissionRecord } from '@/api/maritime/commissionRecord'

/** 佣金记录 表单 */
defineOptions({ name: 'CommissionRecordForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  referrerMemberId: undefined,
  referredEnrollmentId: undefined,
  sessionId: undefined,
  commissionAmount: undefined,
  commissionStatus: undefined,
  expectedSettleDate: undefined,
  isRiskFlagged: undefined,
  riskCheckResult: undefined,
  triggerTime: undefined,
  settleCheckTime: undefined,
  approveTime: undefined,
  approverId: undefined,
  approveRemark: undefined,
  payoutTime: undefined,
  payTransferId: undefined,
  failReason: undefined,
  retryCount: undefined
})
const formRules = reactive({
  referrerMemberId: [{ required: true, message: '推荐人不能为空', trigger: 'blur' }],
  referredEnrollmentId: [{ required: true, message: '被推荐人的报名ID不能为空', trigger: 'blur' }],
  sessionId: [{ required: true, message: '班期ID不能为空', trigger: 'blur' }],
  commissionAmount: [{ required: true, message: '佣金金额（元）不能为空', trigger: 'blur' }],
  commissionStatus: [{ required: true, message: '状态(WAITING_FOR_CLASS/FROZEN/PENDING_REVIEW/REVIEWING/PENDING_PAYOUT/PAYING/PAID/REJECTED/FAILED/MANUALLY_PAID)不能为空', trigger: 'blur' }],
  expectedSettleDate: [{ required: true, message: '预计结算日期（= 开课日期 + 7天）不能为空', trigger: 'blur' }],
  isRiskFlagged: [{ required: true, message: '是否风控标记不能为空', trigger: 'blur' }],
  triggerTime: [{ required: true, message: '触发时间（全款支付时）不能为空', trigger: 'blur' }],
  retryCount: [{ required: true, message: '自动发放失败后已重试次数不能为空', trigger: 'blur' }]
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await CommissionRecordApi.getCommissionRecord(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as CommissionRecord
    if (formType.value === 'create') {
      await CommissionRecordApi.createCommissionRecord(data)
      message.success(t('common.createSuccess'))
    } else {
      await CommissionRecordApi.updateCommissionRecord(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    referrerMemberId: undefined,
    referredEnrollmentId: undefined,
    sessionId: undefined,
    commissionAmount: undefined,
    commissionStatus: undefined,
    expectedSettleDate: undefined,
    isRiskFlagged: undefined,
    riskCheckResult: undefined,
    triggerTime: undefined,
    settleCheckTime: undefined,
    approveTime: undefined,
    approverId: undefined,
    approveRemark: undefined,
    payoutTime: undefined,
    payTransferId: undefined,
    failReason: undefined,
    retryCount: undefined
  }
  formRef.value?.resetFields()
}
</script>
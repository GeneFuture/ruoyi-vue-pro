<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="拼团记录ID" prop="grouponRecordId">
        <el-input v-model="formData.grouponRecordId" placeholder="请输入拼团记录ID" />
      </el-form-item>
      <el-form-item label="报名ID" prop="enrollmentId">
        <el-input v-model="formData.enrollmentId" placeholder="请输入报名ID" />
      </el-form-item>
      <el-form-item label="学员ID" prop="memberId">
        <el-input v-model="formData.memberId" placeholder="请输入学员ID" />
      </el-form-item>
      <el-form-item label="加入时间" prop="joinTime">
        <el-date-picker
          v-model="formData.joinTime"
          type="date"
          value-format="x"
          placeholder="选择加入时间"
        />
      </el-form-item>
      <el-form-item label="成员状态（ACTIVE正常/CANCELLED已退出）" prop="memberStatus">
        <el-radio-group v-model="formData.memberStatus">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="定金支付时间（用于24h拼团有效期检查）" prop="depositPaidAt">
        <el-date-picker
          v-model="formData.depositPaidAt"
          type="date"
          value-format="x"
          placeholder="选择定金支付时间（用于24h拼团有效期检查）"
        />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { GrouponMemberApi, GrouponMember } from '@/api/maritime/grouponMember'

/** 拼团成员 表单 */
defineOptions({ name: 'GrouponMemberForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  grouponRecordId: undefined,
  enrollmentId: undefined,
  memberId: undefined,
  joinTime: undefined,
  memberStatus: undefined,
  depositPaidAt: undefined
})
const formRules = reactive({
  grouponRecordId: [{ required: true, message: '拼团记录ID不能为空', trigger: 'blur' }],
  enrollmentId: [{ required: true, message: '报名ID不能为空', trigger: 'blur' }],
  memberId: [{ required: true, message: '学员ID不能为空', trigger: 'blur' }],
  joinTime: [{ required: true, message: '加入时间不能为空', trigger: 'blur' }],
  memberStatus: [{ required: true, message: '成员状态（ACTIVE正常/CANCELLED已退出）不能为空', trigger: 'blur' }]
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await GrouponMemberApi.getGrouponMember(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as GrouponMember
    if (formType.value === 'create') {
      await GrouponMemberApi.createGrouponMember(data)
      message.success(t('common.createSuccess'))
    } else {
      await GrouponMemberApi.updateGrouponMember(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    grouponRecordId: undefined,
    enrollmentId: undefined,
    memberId: undefined,
    joinTime: undefined,
    memberStatus: undefined,
    depositPaidAt: undefined
  }
  formRef.value?.resetFields()
}
</script>
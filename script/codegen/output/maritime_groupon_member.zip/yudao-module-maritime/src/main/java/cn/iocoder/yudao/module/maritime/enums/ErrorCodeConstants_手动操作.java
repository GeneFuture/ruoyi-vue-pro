// TODO 待办：请将下面的错误码复制到 yudao-module-maritime 模块的 ErrorCodeConstants 类中。注意，请给“TODO 补充编号”设置一个错误码编号！！！
// ========== 拼团成员 TODO 补充编号 ==========
ErrorCode GROUPON_MEMBER_NOT_EXISTS = new ErrorCode(TODO 补充编号, "拼团成员不存在");